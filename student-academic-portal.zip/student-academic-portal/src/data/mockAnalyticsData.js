// Colors adhering to specifications:
// - Top scorer: Red (#EF4444)
// - Class average: Green (#10B981)
// - Logged-in student: Blue (#2563EB)

export const GRAPH_COLORS = {
  student: "#2563EB",     // Blue
  topScorer: "#EF4444",   // Red
  classAverage: "#10B981", // Green
  secondaryBlue: "#93C5FD",
  neutralLight: "#F1F5F9",
  slateDark: "#1E293B"
};

export const subjectPerformanceComparison = [
  {
    subjectCode: "CS601",
    subjectName: "Algorithms (DAA)",
    studentScore: 88,
    classAverage: 71,
    topScore: 96,
  },
  {
    subjectCode: "CS602",
    subjectName: "Database Systems",
    studentScore: 84,
    classAverage: 69,
    topScore: 98,
  },
  {
    subjectCode: "CS603",
    subjectName: "Computer Networks",
    studentScore: 72,
    classAverage: 68,
    topScore: 94,
  },
  {
    subjectCode: "CS604",
    subjectName: "Compiler Design",
    studentScore: 65,
    classAverage: 64,
    topScore: 92,
  },
  {
    subjectCode: "CS605",
    subjectName: "Machine Learning",
    studentScore: 92,
    classAverage: 74,
    topScore: 97,
  },
  {
    subjectCode: "CS606L",
    subjectName: "Web Tech Lab",
    studentScore: 95,
    classAverage: 82,
    topScore: 99,
  }
];

export const semesterTrendComparison = [
  {
    semester: "Semester 1",
    studentScore: 8.10,
    classAverage: 7.20,
    topScore: 9.60,
  },
  {
    semester: "Semester 2",
    studentScore: 8.25,
    classAverage: 7.35,
    topScore: 9.70,
  },
  {
    semester: "Semester 3",
    studentScore: 8.15,
    classAverage: 7.10,
    topScore: 9.50,
  },
  {
    semester: "Semester 4",
    studentScore: 8.55,
    classAverage: 7.45,
    topScore: 9.80,
  },
  {
    semester: "Semester 5",
    studentScore: 8.70,
    classAverage: 7.60,
    topScore: 9.75,
  },
  {
    semester: "Semester 6 (Projected)",
    studentScore: 8.85,
    classAverage: 7.65,
    topScore: 9.85,
  }
];

export const studyPlannerSchedule = [
  {
    id: "sp-1",
    day: "Monday",
    time: "04:30 PM - 06:00 PM",
    subject: "Compiler Design",
    topic: "LL(1) & LR Parsing Tables",
    difficulty: "High",
    status: "Completed",
    suggestedFocus: "High priority due to recent quiz gap"
  },
  {
    id: "sp-2",
    day: "Tuesday",
    time: "05:00 PM - 06:30 PM",
    subject: "Computer Networks",
    topic: "TCP Congestion Control & Sliding Window",
    difficulty: "Medium",
    status: "Upcoming",
    suggestedFocus: "Review numerical problems"
  },
  {
    id: "sp-3",
    day: "Wednesday",
    time: "06:30 PM - 07:30 PM",
    subject: "Senior Mentorship Session",
    topic: "Resume & Dynamic Programming Interview Prep",
    difficulty: "High",
    status: "Confirmed",
    suggestedFocus: "Rohan Varma (Google SWE Intern)"
  },
  {
    id: "sp-4",
    day: "Thursday",
    time: "04:00 PM - 05:30 PM",
    subject: "Algorithms",
    topic: "Bellman-Ford & Floyd-Warshall graph algorithms",
    difficulty: "Medium",
    status: "Upcoming",
    suggestedFocus: "Practice implementation in C++"
  },
  {
    id: "sp-5",
    day: "Friday",
    time: "05:00 PM - 07:00 PM",
    subject: "Machine Learning",
    topic: "Backpropagation math & Gradient Descent",
    difficulty: "High",
    status: "Upcoming",
    suggestedFocus: "Strong area - aim for mastery"
  }
];
