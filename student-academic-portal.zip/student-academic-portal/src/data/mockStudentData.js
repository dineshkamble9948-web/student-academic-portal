export const currentStudent = {
  id: "STU-2022-CSE-048",
  name: "Aarav Sharma",
  email: "aarav.sharma@college.edu",
  department: "Computer Science & Engineering",
  degree: "B.Tech",
  semester: 6,
  academicYear: "2023 - 2024",
  rollNumber: "2022CSE048",
  section: "CSE - 6A",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80",
  mentor: {
    name: "Dr. K. S. Rao",
    designation: "Professor & Academic Mentor",
    cabin: "Academic Block 3, Room 412"
  },
  stats: {
    cgpa: 8.42,
    cgpaScale: 10.0,
    targetCgpa: 9.0,
    classRank: 14,
    totalStudents: 120,
    totalCreditsCompleted: 112,
    totalCreditsRequired: 160,
    attendanceRate: 88.5,
    pendingAssignments: 3,
    activeMentorshipSessions: 2,
    studyHoursThisWeek: 26.5
  }
};

export const semesterHistory = [
  { semester: "Sem 1", studentSgpa: 8.10, topperSgpa: 9.60, classAverageSgpa: 7.20 },
  { semester: "Sem 2", studentSgpa: 8.25, topperSgpa: 9.70, classAverageSgpa: 7.35 },
  { semester: "Sem 3", studentSgpa: 8.15, topperSgpa: 9.50, classAverageSgpa: 7.10 },
  { semester: "Sem 4", studentSgpa: 8.55, topperSgpa: 9.80, classAverageSgpa: 7.45 },
  { semester: "Sem 5", studentSgpa: 8.70, topperSgpa: 9.75, classAverageSgpa: 7.60 },
  { semester: "Sem 6 (Current)", studentSgpa: 8.85, topperSgpa: 9.85, classAverageSgpa: 7.65 },
];

export const currentSemesterSubjects = [
  {
    code: "CS601",
    name: "Design & Analysis of Algorithms",
    credits: 4,
    faculty: "Dr. Arvind Gupta",
    attendance: 92,
    internalMarks: 44, // out of 50
    studentScore: 88,
    classAverage: 71,
    topScore: 96,
    status: "Strong",
    riskLevel: "Low"
  },
  {
    code: "CS602",
    name: "Database Management Systems",
    credits: 4,
    faculty: "Prof. Priya Venkatesh",
    attendance: 86,
    internalMarks: 42,
    studentScore: 84,
    classAverage: 69,
    topScore: 98,
    status: "Proficient",
    riskLevel: "Low"
  },
  {
    code: "CS603",
    name: "Computer Networks & Security",
    credits: 4,
    faculty: "Dr. Rajeshwar Nair",
    attendance: 84,
    internalMarks: 36,
    studentScore: 72,
    classAverage: 68,
    topScore: 94,
    status: "Needs Focus",
    riskLevel: "Medium"
  },
  {
    code: "CS604",
    name: "Compiler Design",
    credits: 3,
    faculty: "Prof. Sunita Menon",
    attendance: 78,
    internalMarks: 32,
    studentScore: 65,
    classAverage: 64,
    topScore: 92,
    status: "Attention Required",
    riskLevel: "High"
  },
  {
    code: "CS605",
    name: "Machine Learning Foundations",
    credits: 4,
    faculty: "Dr. Vikram Seth",
    attendance: 95,
    internalMarks: 47,
    studentScore: 92,
    classAverage: 74,
    topScore: 97,
    status: "Exemplary",
    riskLevel: "Low"
  },
  {
    code: "CS606L",
    name: "Advanced Web Technologies Lab",
    credits: 2,
    faculty: "Prof. Meera Joshi",
    attendance: 96,
    internalMarks: 48,
    studentScore: 95,
    classAverage: 82,
    topScore: 99,
    status: "Exemplary",
    riskLevel: "Low"
  }
];

export const upcomingTasks = [
  {
    id: 1,
    title: "Algorithms Dynamic Programming Assignment",
    course: "CS601 - DAA",
    dueDate: "Tomorrow, 11:59 PM",
    dueTimestamp: "2026-11-16T23:59:00",
    priority: "High",
    status: "In Progress",
    progress: 75
  },
  {
    id: 2,
    title: "DBMS Mini-Project Schema & Normalization Report",
    course: "CS602 - DBMS",
    dueDate: "Nov 19, 2026",
    dueTimestamp: "2026-11-19T17:00:00",
    priority: "Medium",
    status: "Drafting",
    progress: 40
  },
  {
    id: 3,
    title: "Networks Wireshark Packet Capture Analysis",
    course: "CS603 - CNS",
    dueDate: "Nov 22, 2026",
    dueTimestamp: "2026-11-22T23:59:00",
    priority: "High",
    status: "Not Started",
    progress: 0
  }
];

export const seniorMentors = [
  {
    id: "MEN-01",
    name: "Rohan Varma",
    year: "Final Year (4th Year)",
    branch: "Computer Science",
    companyPlacement: "Google (SWE Intern) / Post-Grad Admit",
    rating: 4.9,
    reviewsCount: 38,
    domains: ["Competitive Programming", "System Design", "Algorithms"],
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80",
    availability: "Available this Wednesday & Saturday"
  },
  {
    id: "MEN-02",
    name: "Ananya Deshmukh",
    year: "Final Year (4th Year)",
    branch: "Information Technology",
    companyPlacement: "Microsoft (Full-time FTE)",
    rating: 5.0,
    reviewsCount: 52,
    domains: ["Machine Learning", "Research Papers", "CGPA Strategy"],
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80",
    availability: "Available Tomorrow 5:00 PM"
  },
  {
    id: "MEN-03",
    name: "Karan Singhania",
    year: "Final Year (4th Year)",
    branch: "Computer Science",
    companyPlacement: "Amazon (SDE-1)",
    rating: 4.8,
    reviewsCount: 29,
    domains: ["Full Stack Development", "Resume Review", "Core CS Prep"],
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80",
    availability: "Available Weekend slots"
  }
];
