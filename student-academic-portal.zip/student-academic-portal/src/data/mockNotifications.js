export const mockNotifications = [
  {
    id: "notif-1",
    title: "Mid-Term Examination Schedule Released",
    category: "Academic",
    message: "The Semester 6 Mid-Term Examination schedule has been published by the Controller of Examinations. Exams start on Dec 2, 2026.",
    timestamp: "10 mins ago",
    read: false,
    priority: "high"
  },
  {
    id: "notif-2",
    title: "Senior Mentorship Slot Confirmed",
    category: "Mentorship",
    message: "Your 1-on-1 session with Rohan Varma (Google SWE Intern) is confirmed for Wednesday at 6:30 PM IST via Google Meet.",
    timestamp: "2 hours ago",
    read: false,
    priority: "medium"
  },
  {
    id: "notif-3",
    title: "Algorithms Assignment Submission Reminder",
    category: "Submission",
    message: "CS601: Dynamic Programming set is due tomorrow at 11:59 PM. Please verify your PDF & test report before uploading.",
    timestamp: "5 hours ago",
    read: false,
    priority: "high"
  },
  {
    id: "notif-4",
    title: "CGPA Prediction Engine Updated",
    category: "Analytics",
    message: "Based on your recent Internal Assessment 2 scores, your projected Sem 6 SGPA improved from 8.65 to 8.85.",
    timestamp: "1 day ago",
    read: true,
    priority: "low"
  },
  {
    id: "notif-5",
    title: "Library Book Due Notice",
    category: "Administrative",
    message: "Introduction to Algorithms (CLRS 4th Ed) is due for renewal or return on Nov 18, 2026.",
    timestamp: "2 days ago",
    read: true,
    priority: "low"
  }
];
