import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from '../components/common/ProtectedRoute';
import DashboardLayout from '../components/layout/DashboardLayout';
import Login from '../pages/auth/Login';
import Registration from '../pages/auth/Registration';
import StudentDashboard from '../pages/dashboard/StudentDashboard';
import AcademicPerformance from '../pages/analytics/AcademicPerformance';
import SubjectAnalytics from '../pages/analytics/SubjectAnalytics';
import TopperComparison from '../pages/analytics/TopperComparison';
import CgpaImprovement from '../pages/analytics/CgpaImprovement';
import SeniorMentorship from '../pages/mentorship/SeniorMentorship';
import SmartStudyPlanner from '../pages/planner/SmartStudyPlanner';
import AssignmentsProjects from '../pages/assignments/AssignmentsProjects';
import Notifications from '../pages/notifications/Notifications';
import Profile from '../pages/profile/Profile';

export const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Authentication Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Registration />} />

      {/* Protected Dashboard Shell Routes */}
      <Route
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="/analytics/performance" element={<AcademicPerformance />} />
        <Route path="/analytics/subjects" element={<SubjectAnalytics />} />
        <Route path="/analytics/topper-comparison" element={<TopperComparison />} />
        <Route path="/analytics/cgpa-improvement" element={<CgpaImprovement />} />
        <Route path="/mentorship" element={<SeniorMentorship />} />
        <Route path="/planner" element={<SmartStudyPlanner />} />
        <Route path="/assignments" element={<AssignmentsProjects />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/profile" element={<Profile />} />
      </Route>

      {/* Fallback Catch-all Route */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};

export default AppRoutes;
