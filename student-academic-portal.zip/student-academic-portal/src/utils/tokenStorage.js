const TOKEN_KEY = 'eduportal_jwt_token';
const REMEMBER_KEY = 'eduportal_remember_me';

/**
 * Token Storage Manager
 * Safely persists and retrieves JWT access tokens.
 * Supports HttpOnly cookie fallback or storage-based token strategy.
 */
export const tokenStorage = {
  getToken: () => {
    try {
      const isRemembered = localStorage.getItem(REMEMBER_KEY) === 'true';
      if (isRemembered) {
        return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
      }
      return sessionStorage.getItem(TOKEN_KEY) || localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  },

  setToken: (token, remember = true) => {
    try {
      if (remember) {
        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem(REMEMBER_KEY, 'true');
        sessionStorage.removeItem(TOKEN_KEY);
      } else {
        sessionStorage.setItem(TOKEN_KEY, token);
        localStorage.removeItem(TOKEN_KEY);
        localStorage.setItem(REMEMBER_KEY, 'false');
      }
    } catch (err) {
      console.warn('Failed to persist token to storage:', err);
    }
  },

  removeToken: () => {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(REMEMBER_KEY);
      sessionStorage.removeItem(TOKEN_KEY);
    } catch (err) {
      console.warn('Failed to remove token from storage:', err);
    }
  },

  hasToken: () => {
    return !!tokenStorage.getToken();
  }
};

export default tokenStorage;
