import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import authService from '../services/authService';
import tokenStorage from '../utils/tokenStorage';

const AuthContext = createContext(null);

// Format and normalize user object with safe metric fallbacks
const normalizeUser = (rawUser) => {
  if (!rawUser) return null;
  return {
    ...rawUser,
    id: rawUser.id || rawUser._id,
    department: rawUser.branch || rawUser.department || 'Computer Science & Engineering',
    semester: rawUser.currentSemester || rawUser.semester || 5,
    academicYear: rawUser.academicYear || '2023 - 2024',
    section: rawUser.section || `${rawUser.branch || 'CSE'} - ${rawUser.currentSemester || 5}A`,
    avatar: rawUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    stats: {
      cgpa: rawUser.stats?.cgpa ?? rawUser.cgpa ?? 7.42,
      cgpaScale: 10.0,
      targetCgpa: rawUser.stats?.targetCgpa ?? 9.0,
      classRank: rawUser.stats?.classRank ?? 14,
      totalStudents: rawUser.stats?.totalStudents ?? 120,
      totalCreditsCompleted: rawUser.stats?.totalCreditsCompleted ?? 112,
      totalCreditsRequired: 160,
      attendanceRate: rawUser.stats?.attendanceRate ?? 88.5,
      pendingAssignments: rawUser.stats?.pendingAssignments ?? 3,
      activeMentorshipSessions: rawUser.stats?.activeMentorshipSessions ?? 2,
      studyHoursThisWeek: rawUser.stats?.studyHoursThisWeek ?? 26.5
    }
  };
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  // Initialize session verification on mount
  const checkSession = useCallback(async () => {
    setLoading(true);
    setAuthError(null);

    if (tokenStorage.hasToken()) {
      try {
        const response = await authService.getCurrentUser();
        if (response && response.user) {
          setUser(normalizeUser(response.user));
          setIsAuthenticated(true);
        } else {
          setUser(null);
          setIsAuthenticated(false);
          tokenStorage.removeToken();
        }
      } catch (err) {
        console.warn('[AuthContext] Session expired or invalid token:', err.message);
        setUser(null);
        setIsAuthenticated(false);
        tokenStorage.removeToken();
      }
    } else {
      setUser(null);
      setIsAuthenticated(false);
    }

    setLoading(false);
  }, []);

  useEffect(() => {
    checkSession();

    // Listen for global 401 unauthorized events from Axios interceptor
    const handleUnauthorized = () => {
      setUser(null);
      setIsAuthenticated(false);
    };

    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => {
      window.removeEventListener('auth:unauthorized', handleUnauthorized);
    };
  }, [checkSession]);

  /**
   * Log in student (accepts email or roll number as identifier)
   */
  const login = async (identifier, password, rememberMe = true) => {
    setLoading(true);
    setAuthError(null);
    try {
      const response = await authService.login(identifier, password, rememberMe);
      if (response && response.user) {
        const normalized = normalizeUser(response.user);
        setUser(normalized);
        setIsAuthenticated(true);
        return { success: true, user: normalized };
      }
      throw new Error(response.message || 'Invalid response received from authentication server.');
    } catch (err) {
      const errorMessage = err.message || 'Login failed. Please verify your credentials.';
      setAuthError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  /**
   * Register new student
   */
  const register = async (formData) => {
    setLoading(true);
    setAuthError(null);
    try {
      const response = await authService.register(formData);
      if (response && response.user) {
        const normalized = normalizeUser(response.user);
        setUser(normalized);
        setIsAuthenticated(true);
        return { success: true, user: normalized };
      }
      throw new Error(response.message || 'Registration succeeded but session could not be established.');
    } catch (err) {
      const errorMessage = err.message || 'Registration failed.';
      setAuthError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  /**
   * Log out student
   */
  const logout = () => {
    authService.logout();
    setUser(null);
    setIsAuthenticated(false);
    setAuthError(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        loading,
        authError,
        login,
        register,
        logout,
        checkSession,
        setUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
