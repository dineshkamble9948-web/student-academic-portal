import apiClient from './api';
import { tokenStorage } from '../utils/tokenStorage';

/**
 * Authentication Service
 * Communicates with the actual Express backend /api/auth endpoints:
 * - POST /api/auth/login
 * - POST /api/auth/register
 * - GET  /api/auth/me
 */
export const authService = {
  /**
   * Log in student with email or rollNumber
   * @param {string} identifier - Student email or roll number
   * @param {string} password - Student password
   * @param {boolean} rememberMe - Whether to persist token across browser restarts
   * @returns {Promise<{ user: Object, token: string }>}
   */
  login: async (identifier, password, rememberMe = true) => {
    // Backend accepts { identifier, password } or { email, password }
    const response = await apiClient.post('/auth/login', {
      identifier: identifier.trim(),
      password,
    });

    // Backend returns { success: true, statusCode: 200, message: "...", data: { user, token } }
    const token = response?.data?.token || response?.token;
    const user = response?.data?.user || response?.user;

    if (token) {
      tokenStorage.setToken(token, rememberMe);
    }

    return {
      success: response?.success ?? true,
      message: response?.message || 'Login successful',
      token,
      user
    };
  },

  /**
   * Register a new student
   * @param {Object} studentData
   * @returns {Promise<{ user: Object, token: string }>}
   */
  register: async (studentData) => {
    const sem = Number(studentData.currentSemester || studentData.semester || 5);
    const yr = Number(studentData.year || Math.ceil(sem / 2) || 3);
    const br = (studentData.branch || studentData.department || 'CSE').trim();

    // Map fields exactly to backend User model validation requirements
    const payload = {
      name: studentData.name?.trim(),
      rollNumber: studentData.rollNumber?.trim().toUpperCase(),
      email: studentData.email?.trim().toLowerCase(),
      password: studentData.password,
      gender: studentData.gender || 'Male',
      branch: br.length > 5 ? 'CSE' : br.toUpperCase(),
      year: yr,
      currentSemester: sem,
      phone: studentData.phone?.trim() || '+91 9876543210',
      role: 'Student',
      studyPreferences: {
        dailyTargetHours: 3,
        preferredStudyTimes: ['evening', 'night']
      }
    };

    const response = await apiClient.post('/auth/register', payload);

    const token = response?.data?.token || response?.token;
    const user = response?.data?.user || response?.user;

    if (token) {
      tokenStorage.setToken(token, true);
    }

    return {
      success: response?.success ?? true,
      message: response?.message || 'User registered successfully',
      token,
      user
    };
  },

  /**
   * Fetch current authenticated student profile
   * @returns {Promise<{ user: Object }>}
   */
  getCurrentUser: async () => {
    const response = await apiClient.get('/auth/me');
    const user = response?.data?.user || response?.user;
    return {
      success: response?.success ?? true,
      user
    };
  },

  /**
   * Log out student and clear local session
   */
  logout: () => {
    tokenStorage.removeToken();
  },

  /**
   * Check if access token is present
   */
  isAuthenticated: () => {
    return tokenStorage.hasToken();
  }
};

export default authService;
