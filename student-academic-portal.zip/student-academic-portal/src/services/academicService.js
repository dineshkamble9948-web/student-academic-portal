import apiClient from './api';

/**
 * Academic Performance & Analytics Service
 * Targets backend endpoints documented in API_DOCUMENTATION.md:
 * - GET /api/student/performance
 * - GET /api/student/subjects?semester=X
 * - GET /api/student/comparison?semester=X
 * - GET /api/student/cgpa
 * - GET /api/student/weak-subjects?semester=X
 * - GET /api/academic/toppers?semester=X&branch=Y
 */
export const academicService = {
  /**
   * Get all semester performance records and overall CGPA
   * Route: GET /api/student/performance
   */
  getPerformance: async (semester) => {
    const url = semester ? `/student/performance?semester=${semester}` : '/student/performance';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Get detailed subject-wise marks with assessment breakdown (Quiz, Surprise Test, Mid-Term, End-Term)
   * Route: GET /api/student/subjects?semester=X
   */
  getSubjects: async (semester) => {
    const url = semester ? `/student/subjects?semester=${semester}` : '/student/subjects';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Get student comparison against class averages and toppers
   * Route: GET /api/student/comparison?semester=X
   */
  getComparison: async (semester) => {
    const url = semester ? `/student/comparison?semester=${semester}` : '/student/comparison';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Get SGPA trajectory and CGPA overview
   * Route: GET /api/student/cgpa
   */
  getCgpa: async () => {
    const response = await apiClient.get('/student/cgpa');
    return response?.data || response;
  },

  /**
   * Get diagnosed weak subjects
   * Route: GET /api/student/weak-subjects?semester=X
   */
  getWeakSubjects: async (semester) => {
    const url = semester ? `/student/weak-subjects?semester=${semester}` : '/student/weak-subjects';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Get toppers list for semester and branch
   * Route: GET /api/academic/toppers?semester=X&branch=Y
   */
  getToppers: async (semester, branch) => {
    const params = new URLSearchParams();
    if (semester) params.append('semester', semester);
    if (branch) params.append('branch', branch);
    const queryString = params.toString();
    const url = queryString ? `/academic/toppers?${queryString}` : '/academic/toppers';
    const response = await apiClient.get(url);
    return response?.data || response;
  }
};

export default academicService;
