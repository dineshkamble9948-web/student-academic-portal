import apiClient from './api';

/**
 * Smart Study Planner API Service
 * Documented in backend API_DOCUMENTATION.md:
 * - GET   /api/planner?days=7
 * - PATCH /api/planner/tasks/:id/complete
 * - GET   /api/planner/timetable?semester=X&branch=Y
 */
export const plannerService = {
  /**
   * Fetch generated smart study schedule and prioritized task queue
   * Route: GET /api/planner?days=X
   */
  getWeeklyPlan: async (days = 7) => {
    const response = await apiClient.get(`/planner?days=${days}`);
    return response?.data || response;
  },

  /**
   * Mark a planner task completed and trigger dynamic schedule rebalancing
   * Route: PATCH /api/planner/tasks/:id/complete
   */
  completeTask: async (taskId) => {
    const response = await apiClient.patch(`/planner/tasks/${taskId}/complete`);
    return response?.data || response;
  },

  /**
   * Fetch official semester exam timetable
   * Route: GET /api/planner/timetable?semester=X&branch=Y
   */
  getTimetable: async (semester, branch) => {
    const params = new URLSearchParams();
    if (semester) params.append('semester', semester);
    if (branch) params.append('branch', branch);
    const queryString = params.toString();
    const url = queryString ? `/planner/timetable?${queryString}` : '/planner/timetable';
    const response = await apiClient.get(url);
    return response?.data || response;
  }
};

export default plannerService;
