import apiClient from './api';

/**
 * Senior Mentorship API Service
 * Documented in backend API_DOCUMENTATION.md:
 * - GET  /api/mentors
 * - POST /api/mentorship/request
 * - GET  /api/mentorship/my-requests
 */
export const mentorshipService = {
  /**
   * Fetch available senior mentors with optional filters (femaleOnly, subjectCode, branch, minCgpa)
   * Route: GET /api/mentors
   */
  getMentors: async (filters = {}) => {
    const params = new URLSearchParams();
    if (filters.femaleOnly) params.append('femaleOnly', 'true');
    if (filters.subjectCode) params.append('subjectCode', filters.subjectCode);
    if (filters.branch) params.append('branch', filters.branch);
    if (filters.minCgpa) params.append('minCgpa', filters.minCgpa);

    const queryString = params.toString();
    const url = queryString ? `/mentors?${queryString}` : '/mentors';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Submit a new mentorship request to a senior mentor
   * Route: POST /api/mentorship/request
   */
  sendRequest: async (payload) => {
    const response = await apiClient.post('/mentorship/request', payload);
    return response?.data || response;
  },

  /**
   * Fetch student's submitted mentorship requests
   * Route: GET /api/mentorship/my-requests
   */
  getMyRequests: async () => {
    const response = await apiClient.get('/mentorship/my-requests');
    return response?.data || response;
  }
};

export default mentorshipService;
