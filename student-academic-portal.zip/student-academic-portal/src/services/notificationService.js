import apiClient from './api';

/**
 * Notifications & Reminders API Service
 * Documented in backend API_DOCUMENTATION.md:
 * - GET   /api/notifications
 * - PATCH /api/notifications/:id/read
 * - PATCH /api/notifications/read-all
 */
export const notificationService = {
  /**
   * Fetch all notifications
   * Route: GET /api/notifications
   */
  getNotifications: async (unreadOnly = false) => {
    const url = unreadOnly ? '/notifications?unread=true' : '/notifications';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Mark a single notification as read
   * Route: PATCH /api/notifications/:id/read
   */
  markAsRead: async (notificationId) => {
    const response = await apiClient.patch(`/notifications/${notificationId}/read`);
    return response?.data || response;
  },

  /**
   * Mark all notifications as read
   * Route: PATCH /api/notifications/read-all
   */
  markAllAsRead: async () => {
    const response = await apiClient.patch('/notifications/read-all');
    return response?.data || response;
  }
};

export default notificationService;
