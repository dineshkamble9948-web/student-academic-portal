import axios from 'axios';
import { tokenStorage } from '../utils/tokenStorage';

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

/**
 * Centralized Axios API instance with request & response interceptors
 */
export const apiClient = axios.create({
  baseURL: BASE_URL,
  withCredentials: true, // Enables HttpOnly cookies transmission
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request interceptor: Attach JWT token if available
apiClient.interceptors.request.use(
  (config) => {
    const token = tokenStorage.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor: Global error handler & 401 unauthorized cleanup
apiClient.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (error) => {
    // If backend returns 401 Unauthorized and not on login/register
    if (error.response && error.response.status === 401) {
      const isAuthUrl = error.config?.url?.includes('/auth/login') || error.config?.url?.includes('/auth/register');
      if (!isAuthUrl) {
        tokenStorage.removeToken();
        // Dispatch custom event for AuthContext to sync logout
        window.dispatchEvent(new Event('auth:unauthorized'));
      }
    }

    // Extract best human-readable error message
    const message =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      'An unexpected network error occurred. Please check your connection.';

    return Promise.reject(new Error(message));
  }
);

export default apiClient;
