import apiClient from './api';

/**
 * Tasks & Assignments API Service
 * Documented in backend API_DOCUMENTATION.md:
 * - GET    /api/tasks
 * - POST   /api/tasks
 * - PUT    /api/tasks/:id
 * - DELETE /api/tasks/:id
 */
export const taskService = {
  /**
   * Fetch assignments, projects, and study tasks
   * Route: GET /api/tasks
   */
  getTasks: async (filters = {}) => {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.type) params.append('type', filters.type);
    if (filters.subjectCode) params.append('subjectCode', filters.subjectCode);
    if (filters.sortBy) params.append('sortBy', filters.sortBy);

    const queryString = params.toString();
    const url = queryString ? `/tasks?${queryString}` : '/tasks';
    const response = await apiClient.get(url);
    return response?.data || response;
  },

  /**
   * Create a new assignment or project task
   * Route: POST /api/tasks
   */
  createTask: async (taskData) => {
    const response = await apiClient.post('/tasks', taskData);
    return response?.data || response;
  },

  /**
   * Update task details or toggle completion status
   * Route: PUT /api/tasks/:id
   */
  updateTask: async (taskId, updates) => {
    const response = await apiClient.put(`/tasks/${taskId}`, updates);
    return response?.data || response;
  },

  /**
   * Delete a task
   * Route: DELETE /api/tasks/:id
   */
  deleteTask: async (taskId) => {
    const response = await apiClient.delete(`/tasks/${taskId}`);
    return response?.data || response;
  }
};

export default taskService;
