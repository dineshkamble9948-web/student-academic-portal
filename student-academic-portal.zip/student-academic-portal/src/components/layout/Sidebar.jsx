import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  LayoutDashboard,
  BarChart3,
  BookOpen,
  Trophy,
  TrendingUp,
  Users2,
  CalendarCheck,
  FileSpreadsheet,
  Bell,
  UserCircle,
  LogOut,
  X,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import notificationService from '../../services/notificationService';

const getNavGroups = (unreadCount = 0) => [
  {
    group: 'Overview',
    items: [
      {
        name: 'Student Dashboard',
        path: '/dashboard',
        icon: LayoutDashboard,
      },
    ],
  },
  {
    group: 'Academic Analytics',
    items: [
      {
        name: 'Academic Performance',
        path: '/analytics/performance',
        icon: BarChart3,
      },
      {
        name: 'Subject Analytics',
        path: '/analytics/subjects',
        icon: BookOpen,
      },
      {
        name: 'Topper Comparison',
        path: '/analytics/topper-comparison',
        icon: Trophy,
      },
      {
        name: 'CGPA Improvement',
        path: '/analytics/cgpa-improvement',
        icon: TrendingUp,
      },
    ],
  },
  {
    group: 'Mentorship & Planning',
    items: [
      {
        name: 'Senior Mentorship',
        path: '/mentorship',
        icon: Users2,
      },
      {
        name: 'Smart Study Planner',
        path: '/planner',
        icon: CalendarCheck,
      },
      {
        name: 'Assignments & Projects',
        path: '/assignments',
        icon: FileSpreadsheet,
      },
    ],
  },
  {
    group: 'Account',
    items: [
      {
        name: 'Notifications',
        path: '/notifications',
        icon: Bell,
        badge: unreadCount > 0 ? unreadCount : null,
      },
      {
        name: 'Profile',
        path: '/profile',
        icon: UserCircle,
      },
    ],
  },
];

export const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    let isMounted = true;
    const fetchUnread = async () => {
      if (!user) return;
      try {
        const res = await notificationService.getNotifications(true);
        if (!isMounted) return;
        const count = res?.unreadCount ?? (Array.isArray(res?.notifications) ? res.notifications.filter(n => !(n.isRead || n.read)).length : 0);
        setUnreadCount(count);
      } catch (err) {
        // Soft fallback
      }
    };
    fetchUnread();
    return () => {
      isMounted = false;
    };
  }, [user]);

  const navGroups = getNavGroups(unreadCount);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navItemClass = ({ isActive }) =>
    `flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-150 ${
      isActive
        ? 'bg-brand-50 text-brand-700 font-semibold shadow-xs'
        : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900'
    }`;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs transition-opacity lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-white border-r border-slate-200/80 shadow-sm transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="flex h-16 items-center justify-between px-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white shadow-md shadow-brand-500/20">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <span className="text-base font-bold text-slate-900 leading-tight block">
                EduPortal
              </span>
              <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
                Academic Portal
              </span>
            </div>
          </div>

          {/* Close button for mobile */}
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 lg:hidden"
            aria-label="Close Sidebar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-6">
          {navGroups.map((group) => (
            <div key={group.group} className="space-y-1">
              <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                {group.group}
              </p>
              <nav className="mt-1 space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <NavLink
                      key={item.path}
                      to={item.path}
                      onClick={onClose}
                      className={navItemClass}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-4 w-4 shrink-0 text-slate-500 group-hover:text-slate-900" />
                        <span className="truncate">{item.name}</span>
                      </div>

                      {item.badge ? (
                        <span className="ml-auto inline-flex items-center justify-center rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-bold text-white">
                          {item.badge}
                        </span>
                      ) : null}
                    </NavLink>
                  );
                })}
              </nav>
            </div>
          ))}
        </div>

        {/* Current Student Profile Snapshot in Sidebar Footer */}
        {user && (
          <div className="border-t border-slate-100 p-3.5 bg-slate-50/50">
            <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-white border border-slate-200/80 shadow-xs">
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="h-9 w-9 rounded-lg object-cover ring-1 ring-slate-200 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-800 truncate leading-tight">
                    {user.name}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">
                    {user.rollNumber} • Sem {user.semester}
                  </p>
                </div>
              </div>

              <button
                onClick={handleLogout}
                title="Log Out"
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};

export default Sidebar;
