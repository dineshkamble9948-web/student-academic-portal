import React from 'react';
import { Info } from 'lucide-react';

export const ChartCard = ({
  title,
  subtitle,
  actions,
  children,
  showStandardLegend = false,
  className = '',
  infoTooltip
}) => {
  return (
    <div className={`bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900 tracking-tight">{title}</h3>
            {infoTooltip && (
              <span title={infoTooltip} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <Info className="w-4 h-4" />
              </span>
            )}
          </div>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-3">
          {/* Standard comparative legend if requested */}
          {showStandardLegend && (
            <div className="flex flex-wrap items-center gap-3 text-xs font-medium">
              <span className="inline-flex items-center gap-1.5 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]" />
                You (Student)
              </span>
              <span className="inline-flex items-center gap-1.5 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10B981]" />
                Class Average
              </span>
              <span className="inline-flex items-center gap-1.5 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444]" />
                Top Scorer
              </span>
            </div>
          )}

          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </div>
      </div>

      {/* Chart Body */}
      <div className="w-full">
        {children}
      </div>
    </div>
  );
};

export default ChartCard;
