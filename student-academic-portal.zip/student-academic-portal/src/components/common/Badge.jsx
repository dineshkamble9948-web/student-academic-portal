import React from 'react';

const VARIANT_MAP = {
  blue: 'bg-blue-50 text-blue-700 border-blue-200',
  green: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  red: 'bg-rose-50 text-rose-700 border-rose-200',
  amber: 'bg-amber-50 text-amber-700 border-amber-200',
  purple: 'bg-purple-50 text-purple-700 border-purple-200',
  slate: 'bg-slate-100 text-slate-700 border-slate-200',
};

export const Badge = ({
  children,
  variant = 'blue',
  size = 'md',
  className = '',
  dot = false
}) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-medium',
    md: 'text-xs px-2.5 py-1 font-semibold',
    lg: 'text-sm px-3 py-1 font-semibold'
  }[size] || 'text-xs px-2.5 py-1 font-semibold';

  const dotColors = {
    blue: 'bg-blue-600',
    green: 'bg-emerald-600',
    red: 'bg-rose-600',
    amber: 'bg-amber-500',
    purple: 'bg-purple-600',
    slate: 'bg-slate-500',
  }[variant] || 'bg-blue-600';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${VARIANT_MAP[variant] || VARIANT_MAP.blue} ${sizeClasses} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColors}`} />}
      {children}
    </span>
  );
};

export default Badge;
