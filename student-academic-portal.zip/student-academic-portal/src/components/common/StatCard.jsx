import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export const StatCard = ({
  title,
  value,
  subtext,
  icon: Icon,
  iconColor = 'text-brand-600',
  iconBg = 'bg-brand-50',
  trend,
  trendType = 'up', // 'up' | 'down' | 'neutral'
  badgeText,
  className = '',
  onClick
}) => {
  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm card-hover relative overflow-hidden ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold tracking-wider text-slate-500 uppercase">{title}</p>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-slate-900">{value}</span>
            {badgeText && (
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                {badgeText}
              </span>
            )}
          </div>
        </div>

        {Icon && (
          <div className={`p-3 rounded-xl ${iconBg} ${iconColor} shrink-0`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      {(trend || subtext) && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {trend && (
            <div className="flex items-center gap-1 font-medium">
              {trendType === 'up' && (
                <span className="inline-flex items-center gap-0.5 text-emerald-600 font-semibold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  {trend}
                </span>
              )}
              {trendType === 'down' && (
                <span className="inline-flex items-center gap-0.5 text-rose-600 font-semibold">
                  <TrendingDown className="w-3.5 h-3.5" />
                  {trend}
                </span>
              )}
              {trendType === 'neutral' && (
                <span className="inline-flex items-center gap-0.5 text-slate-500 font-semibold">
                  <Minus className="w-3.5 h-3.5" />
                  {trend}
                </span>
              )}
            </div>
          )}

          {subtext && (
            <span className="text-slate-500 text-right truncate ml-auto">{subtext}</span>
          )}
        </div>
      )}
    </div>
  );
};

export default StatCard;
