import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { GRAPH_COLORS } from '../../data/mockAnalyticsData';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/95 backdrop-blur-sm p-3 border border-slate-200 rounded-lg shadow-lg text-xs">
        <p className="font-bold text-slate-800 mb-2">{label}</p>
        <div className="space-y-1">
          {payload.map((entry, index) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 font-medium" style={{ color: entry.color }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                {entry.name}:
              </span>
              <span className="font-bold text-slate-900">{entry.value}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

export const SubjectBarChart = ({ data, height = 320 }) => {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <BarChart
          data={data}
          margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
          barGap={6}
          barSize={14}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
          <XAxis
            dataKey="subjectCode"
            tick={{ fill: '#64748B', fontSize: 12, fontWeight: 500 }}
            tickLine={false}
            axisLine={{ stroke: '#CBD5E1' }}
          />
          <YAxis
            domain={[0, 100]}
            tick={{ fill: '#64748B', fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(val) => `${val}%`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            verticalAlign="top"
            align="right"
            iconType="circle"
            wrapperStyle={{ paddingBottom: 20, fontSize: 12 }}
          />
          {/* Important graph colors as requested:
              - Logged-in student: Blue (#2563EB)
              - Class average: Green (#10B981)
              - Top scorer: Red (#EF4444)
          */}
          <Bar
            name="Your Score (Student)"
            dataKey="studentScore"
            fill={GRAPH_COLORS.student}
            radius={[4, 4, 0, 0]}
          />
          <Bar
            name="Class Average"
            dataKey="classAverage"
            fill={GRAPH_COLORS.classAverage}
            radius={[4, 4, 0, 0]}
          />
          <Bar
            name="Top Scorer"
            dataKey="topScore"
            fill={GRAPH_COLORS.topScorer}
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SubjectBarChart;
