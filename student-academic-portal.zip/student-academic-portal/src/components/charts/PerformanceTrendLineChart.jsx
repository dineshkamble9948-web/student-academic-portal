import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { GRAPH_COLORS } from '../../data/mockAnalyticsData';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/95 backdrop-blur-sm p-3 border border-slate-200 rounded-lg shadow-lg text-xs">
        <p className="font-bold text-slate-800 mb-2">{label}</p>
        <div className="space-y-1">
          {payload.map((entry, index) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 font-medium" style={{ color: entry.color }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                {entry.name}:
              </span>
              <span className="font-bold text-slate-900">{Number(entry.value).toFixed(2)} SGPA</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

export const PerformanceTrendLineChart = ({ data, height = 300 }) => {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <LineChart
          data={data}
          margin={{ top: 20, right: 20, left: -10, bottom: 10 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
          <XAxis
            dataKey="semester"
            tick={{ fill: '#64748B', fontSize: 12 }}
            tickLine={false}
            axisLine={{ stroke: '#CBD5E1' }}
          />
          <YAxis
            domain={[6.0, 10.0]}
            tick={{ fill: '#64748B', fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(val) => val.toFixed(1)}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            verticalAlign="top"
            align="right"
            iconType="circle"
            wrapperStyle={{ paddingBottom: 20, fontSize: 12 }}
          />
          {/* Important graph colors as requested:
              - Top scorer: Red (#EF4444)
              - Class average: Green (#10B981)
              - Logged-in student: Blue (#2563EB)
          */}
          <Line
            type="monotone"
            name="Your SGPA (Student)"
            dataKey="studentScore"
            stroke={GRAPH_COLORS.student}
            strokeWidth={3}
            dot={{ r: 4, fill: GRAPH_COLORS.student, strokeWidth: 2, stroke: '#fff' }}
            activeDot={{ r: 6 }}
          />
          <Line
            type="monotone"
            name="Class Average"
            dataKey="classAverage"
            stroke={GRAPH_COLORS.classAverage}
            strokeWidth={2}
            strokeDasharray="4 4"
            dot={{ r: 3, fill: GRAPH_COLORS.classAverage }}
          />
          <Line
            type="monotone"
            name="Top Scorer"
            dataKey="topScore"
            stroke={GRAPH_COLORS.topScorer}
            strokeWidth={2}
            dot={{ r: 3, fill: GRAPH_COLORS.topScorer }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PerformanceTrendLineChart;
