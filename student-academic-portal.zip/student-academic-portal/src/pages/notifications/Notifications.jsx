import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/layout/PageHeader';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import {
  Bell,
  CheckCheck,
  Check,
  BookOpen,
  Users2,
  Calendar,
  FileText,
  Clock,
  AlertTriangle,
  ArrowRight,
  Filter,
  RefreshCw,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import notificationService from '../../services/notificationService';
import { useAuth } from '../../context/AuthContext';
import { mockNotifications } from '../../data/mockNotifications';

export const Notifications = () => {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [activeFilter, setActiveFilter] = useState('ALL'); // 'ALL' | 'UNREAD' | 'EXAMS' | 'ASSIGNMENTS' | 'MENTORSHIP'

  // Fetch notifications from service
  const loadNotifications = useCallback(async () => {
    setLoading(true);
    setApiError(null);

    try {
      const res = await notificationService.getNotifications();
      if (res?.notifications && Array.isArray(res.notifications) && res.notifications.length > 0) {
        setNotifications(res.notifications);
      } else {
        // Fallback default notifications
        setNotifications(
          mockNotifications.map((n) => ({
            id: n.id,
            _id: n.id,
            title: n.title,
            message: n.message,
            category: n.category || 'Academic',
            priority: n.priority || 'medium',
            isRead: Boolean(n.read),
            createdAt: n.timestamp || 'Today'
          }))
        );
      }
    } catch (err) {
      console.warn('[Notifications] Fetch error:', err.message);
      setApiError(err.message || 'Unable to sync live notifications from server. Showing cached alerts.');
      // Keep verified initial notifications
      setNotifications(
        mockNotifications.map((n) => ({
          id: n.id,
          _id: n.id,
          title: n.title,
          message: n.message,
          category: n.category || 'Academic',
          priority: n.priority || 'medium',
          isRead: Boolean(n.read),
          createdAt: n.timestamp || 'Today'
        }))
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  // Mark single as read
  const handleMarkAsRead = async (id) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id || n._id === id ? { ...n, isRead: true, read: true } : n))
    );
    try {
      await notificationService.markAsRead(id);
    } catch (err) {
      console.warn('Could not sync read status:', err);
    }
  };

  // Mark all as read
  const handleMarkAllAsRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true, read: true })));
    try {
      await notificationService.markAllAsRead();
    } catch (err) {
      console.warn('Could not sync mark all read:', err);
    }
  };

  // Categorize notifications
  const getCategoryMeta = (category = '', title = '') => {
    const text = (String(category) + ' ' + String(title)).toLowerCase();
    if (text.includes('exam') || text.includes('timetable') || text.includes('mid-term')) {
      return {
        icon: Calendar,
        label: 'Upcoming Exam Reminder',
        variant: 'red',
        bg: 'bg-rose-50 text-rose-600 border-rose-200',
        route: '/planner'
      };
    }
    if (text.includes('assignment') || text.includes('submission') || text.includes('deadline') || text.includes('project')) {
      return {
        icon: FileText,
        label: 'Assignment Deadline Reminder',
        variant: 'amber',
        bg: 'bg-amber-50 text-amber-600 border-amber-200',
        route: '/assignments'
      };
    }
    if (text.includes('mentor') || text.includes('session') || text.includes('request')) {
      return {
        icon: Users2,
        label: 'Mentorship Update',
        variant: 'blue',
        bg: 'bg-blue-50 text-blue-600 border-blue-200',
        route: '/mentorship'
      };
    }
    return {
      icon: BookOpen,
      label: 'Academic Circular',
      variant: 'purple',
      bg: 'bg-purple-50 text-purple-600 border-purple-200',
      route: '/analytics/performance'
    };
  };

  // Filter items
  const filteredNotifications = notifications.filter((item) => {
    const isItemRead = item.isRead ?? item.read;
    if (activeFilter === 'UNREAD') return !isItemRead;

    const meta = getCategoryMeta(item.category || item.type, item.title);
    if (activeFilter === 'EXAMS') return meta.label.includes('Exam');
    if (activeFilter === 'ASSIGNMENTS') return meta.label.includes('Assignment');
    if (activeFilter === 'MENTORSHIP') return meta.label.includes('Mentorship');

    return true;
  });

  const unreadCount = notifications.filter((n) => !(n.isRead ?? n.read)).length;

  return (
    <div className="space-y-6">
      <PageHeader
        category="Academic Communication"
        title="Notifications & Academic Broadcasts"
        description="Official alerts for upcoming examinations, project submission deadlines, senior mentorship updates, and department circulars."
        actions={
          <div className="flex items-center gap-3">
            {unreadCount > 0 && (
              <Button
                variant="secondary"
                size="sm"
                icon={CheckCheck}
                onClick={handleMarkAllAsRead}
              >
                Mark All as Read ({unreadCount})
              </Button>
            )}
          </div>
        }
      />

      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={loadNotifications}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* Filter Tabs Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setActiveFilter('ALL')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeFilter === 'ALL'
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            All Alerts ({notifications.length})
          </button>

          <button
            onClick={() => setActiveFilter('UNREAD')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 ${
              activeFilter === 'UNREAD'
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Unread
            {unreadCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
            )}
          </button>

          <button
            onClick={() => setActiveFilter('EXAMS')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeFilter === 'EXAMS'
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Exam Reminders
          </button>

          <button
            onClick={() => setActiveFilter('ASSIGNMENTS')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeFilter === 'ASSIGNMENTS'
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Assignment Deadlines
          </button>

          <button
            onClick={() => setActiveFilter('MENTORSHIP')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeFilter === 'MENTORSHIP'
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Mentorship Updates
          </button>
        </div>

        <button
          onClick={loadNotifications}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          title="Reload notifications"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Notifications List */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center text-slate-400 text-xs">
          <RefreshCw className="w-6 h-6 animate-spin text-brand-600 mb-2" />
          <span>Syncing academic notifications...</span>
        </div>
      ) : filteredNotifications.length === 0 ? (
        <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 p-8 text-xs text-slate-500">
          <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="font-bold text-slate-700">No notifications found</p>
          <p className="mt-0.5">You're all caught up on academic deadlines and broadcasts.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredNotifications.map((item) => {
            const itemId = item.id || item._id;
            const isItemRead = Boolean(item.isRead ?? item.read);
            const meta = getCategoryMeta(item.category || item.type, item.title);
            const Icon = meta.icon;

            return (
              <div
                key={itemId}
                className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-4 ${
                  isItemRead
                    ? 'bg-white border-slate-200/80 shadow-xs'
                    : 'bg-blue-50/40 border-blue-200 shadow-sm'
                }`}
              >
                <div className="flex items-start gap-4 flex-1">
                  {/* Category Icon */}
                  <div className={`p-2.5 rounded-2xl shrink-0 border ${meta.bg}`}>
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                        {!isItemRead && (
                          <span className="flex h-2 w-2 relative">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-600"></span>
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-medium">
                        {item.createdAt ? new Date(item.createdAt).toLocaleDateString() : item.timestamp || 'Today'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.message}
                    </p>

                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <Badge variant={meta.variant} size="sm">
                        {meta.label}
                      </Badge>

                      {item.priority === 'high' && (
                        <Badge variant="red" size="sm">
                          High Priority
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center gap-2 self-end sm:self-center shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 w-full sm:w-auto justify-end">
                  {!isItemRead && (
                    <button
                      onClick={() => handleMarkAsRead(itemId)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1"
                      title="Mark as Read"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Mark Read
                    </button>
                  )}

                  <Link to={meta.route}>
                    <Button variant="outline" size="sm" icon={ArrowRight} iconPosition="right">
                      View
                    </Button>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Notifications;
