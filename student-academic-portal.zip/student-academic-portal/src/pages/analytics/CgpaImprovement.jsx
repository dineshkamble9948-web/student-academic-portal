import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/layout/PageHeader';
import ChartCard from '../../components/common/ChartCard';
import StatCard from '../../components/common/StatCard';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import PerformanceTrendLineChart from '../../components/charts/PerformanceTrendLineChart';
import {
  Target,
  Calculator,
  Sparkles,
  AlertTriangle,
  Award,
  TrendingUp,
  ArrowRight,
  BookOpen,
  Users2,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ThumbsUp
} from 'lucide-react';
import academicService from '../../services/academicService';
import { useAuth } from '../../context/AuthContext';
import { semesterTrendComparison } from '../../data/mockAnalyticsData';

export const CgpaImprovement = () => {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [cgpaData, setCgpaData] = useState(null);
  const [weakSubjects, setWeakSubjects] = useState([]);
  const [targetCgpa, setTargetCgpa] = useState(9.0);

  const currentCgpa = cgpaData?.cgpa || user?.stats?.cgpa || 8.42;
  const currentSgpa = 8.85;
  const completedSemesters = cgpaData?.completedSemesters || 5;
  const remainingSemesters = Math.max(1, 8 - completedSemesters);

  const fetchCgpaOverview = useCallback(async () => {
    setLoading(true);
    setApiError(null);

    try {
      const [cgpaRes, weakRes] = await Promise.all([
        academicService.getCgpa(),
        academicService.getWeakSubjects(user?.semester || 5)
      ]);

      setCgpaData(cgpaRes);
      if (weakRes?.weakSubjects && Array.isArray(weakRes.weakSubjects)) {
        setWeakSubjects(weakRes.weakSubjects);
      }
    } catch (err) {
      console.warn('[CgpaImprovement] Fetch error:', err.message);
      setApiError(err.message || 'Unable to sync live CGPA and diagnostic metrics. Showing cached records.');
    } finally {
      setLoading(false);
    }
  }, [user?.semester]);

  useEffect(() => {
    fetchCgpaOverview();
  }, [fetchCgpaOverview]);

  // CGPA math simulation:
  // Target total points = targetCgpa * 8
  // Current accumulated points = currentCgpa * completedSemesters
  // Needed average SGPA = (targetTotal - currentAccumulated) / remainingSemesters
  const targetTotal = targetCgpa * 8;
  const currentAccumulated = currentCgpa * completedSemesters;
  const neededSgpa = Number(((targetTotal - currentAccumulated) / remainingSemesters).toFixed(2));
  const isAchievable = neededSgpa <= 10.0 && neededSgpa >= 0;

  return (
    <div className="space-y-6">
      <PageHeader
        category="CGPA Strategy & Improvement"
        title="CGPA Progression, Weak Subjects & Goal Simulator"
        description="Monitor multi-term grade point trajectories, isolate vulnerable academic areas, and simulate targets to boost graduation honours."
      />

      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={fetchCgpaOverview}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Current CGPA"
          value={Number(currentCgpa).toFixed(2)}
          subtext="Graduation scale: 10.00"
          icon={Award}
          iconColor="text-blue-600"
          iconBg="bg-blue-50"
          trend="+0.15 this year"
          trendType="up"
        />
        <StatCard
          title="Current Term SGPA"
          value={Number(currentSgpa).toFixed(2)}
          subtext={`Semester ${user?.semester || 5} Performance`}
          icon={TrendingUp}
          iconColor="text-emerald-600"
          iconBg="bg-emerald-50"
          trend="Strong trajectory"
          trendType="up"
        />
        <StatCard
          title="Target CGPA"
          value={Number(targetCgpa).toFixed(2)}
          subtext="Goal set by student"
          icon={Target}
          iconColor="text-indigo-600"
          iconBg="bg-indigo-50"
          badgeText="In Focus"
        />
        <StatCard
          title="Identified Weak Subjects"
          value={weakSubjects.length}
          subtext="Requiring focused revision"
          icon={AlertTriangle}
          iconColor="text-amber-600"
          iconBg="bg-amber-50"
          badgeText={weakSubjects.length > 0 ? 'Needs Attention' : 'All Clear'}
        />
      </div>

      {/* Semester-wise Progress Chart */}
      <ChartCard
        title="Semester-wise SGPA & CGPA Progress Trajectory"
        subtitle="Tracking student performance (Blue) against class average (Green) and topper (Red)"
        showStandardLegend={true}
      >
        <PerformanceTrendLineChart data={semesterTrendComparison} height={320} />
      </ChartCard>

      {/* Weak Subjects Diagnosis Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              Subjects Requiring Academic Attention
            </h3>
            <p className="text-xs text-slate-500">
              Isolating subjects with internal marks deficit, negative quiz trends, or score below class benchmarks.
            </p>
          </div>
          <Link to="/mentorship">
            <Button variant="outline" size="sm" icon={Users2}>
              Browse Senior Mentors
            </Button>
          </Link>
        </div>

        {weakSubjects.length === 0 ? (
          <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-2">
            <ThumbsUp className="w-10 h-10 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold text-slate-900">All Enrolled Subjects are On Track!</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              No critical performance deficits detected for this term. Your scores meet or exceed class benchmark thresholds.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {weakSubjects.map((item) => {
              const isCritical = item.severity === 'Critical';
              return (
                <div
                  key={item.subjectCode}
                  className={`p-5 rounded-2xl border transition-shadow shadow-xs hover:shadow-md ${
                    isCritical ? 'bg-rose-50/40 border-rose-200' : 'bg-amber-50/40 border-amber-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="font-mono text-xs font-semibold text-slate-500">
                        {item.subjectCode} • {item.credits} Credits
                      </span>
                      <h4 className="text-base font-bold text-slate-900 mt-0.5">
                        {item.subjectName}
                      </h4>
                    </div>
                    <Badge variant={isCritical ? 'red' : 'amber'} size="sm" dot>
                      {item.severity} Severity
                    </Badge>
                  </div>

                  <div className="mt-3 flex items-center gap-4 text-xs font-medium">
                    <div>
                      <span className="text-slate-500 block">Your Score</span>
                      <span className="font-bold text-slate-900 text-sm">{item.studentMarks?.total || 65}%</span>
                    </div>
                    <div className="border-l border-slate-200 pl-4">
                      <span className="text-slate-500 block">Class Avg</span>
                      <span className="font-bold text-emerald-600 text-sm">{item.classAverageTotal || 74.5}%</span>
                    </div>
                    <div className="border-l border-slate-200 pl-4">
                      <span className="text-slate-500 block">Marks Gap</span>
                      <span className="font-bold text-rose-600 text-sm">-{item.marksGap || 9.5}%</span>
                    </div>
                  </div>

                  {/* Reasons Identified */}
                  <div className="mt-4 space-y-1.5">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      Why Attention is Needed:
                    </p>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {item.reasons?.map((reason, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-rose-500 font-bold shrink-0">•</span>
                          <span>{reason}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Recommendations */}
                  <div className="mt-4 p-3 rounded-xl bg-white/80 border border-slate-200/80 space-y-1.5">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-brand-600" />
                      Targeted Improvement Strategy:
                    </p>
                    <ul className="space-y-1 text-xs text-slate-600">
                      {item.recommendations?.map((rec, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Action button */}
                  <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      Weakness Index: <strong className="text-slate-800">{item.weaknessScore || 75}/100</strong>
                    </span>
                    <Link to="/mentorship">
                      <Button variant="primary" size="sm" icon={ArrowRight} iconPosition="right">
                        Get Senior Guidance
                      </Button>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Target Simulator & Strategic Roadmap */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Simulator controls */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Target className="w-5 h-5 text-brand-600" />
            <h3 className="font-bold text-slate-900 text-base">Graduation Target Simulator</h3>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600">
              Desired Cumulative CGPA at Graduation
            </label>
            <div className="mt-2 flex items-center gap-4">
              <input
                type="range"
                min="8.0"
                max="9.8"
                step="0.05"
                value={targetCgpa}
                onChange={(e) => setTargetCgpa(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
              />
              <span className="text-xl font-bold text-brand-600 font-mono min-w-14 text-right">
                {targetCgpa.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-400 mt-1">
              <span>Current: {Number(currentCgpa).toFixed(2)}</span>
              <span>Max: 9.80</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Semesters Completed:</span>
              <span className="font-semibold text-slate-800">{completedSemesters} (112 Credits)</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Semesters Remaining:</span>
              <span className="font-semibold text-slate-800">{remainingSemesters} (48 Credits)</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Current Baseline CGPA:</span>
              <span className="font-bold text-blue-600">{Number(currentCgpa).toFixed(2)}</span>
            </div>
          </div>

          <div className={`p-4 rounded-xl border ${isAchievable ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'}`}>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-600">
              Required Average SGPA (Remaining Sems)
            </p>
            <p className={`text-3xl font-extrabold mt-1 ${isAchievable ? 'text-emerald-700' : 'text-rose-700'}`}>
              {neededSgpa.toFixed(2)} <span className="text-sm font-normal text-slate-500">/ 10.0</span>
            </p>
            <p className="text-xs text-slate-600 mt-2">
              {isAchievable
                ? 'Target is mathematically achievable with consistent grade point execution.'
                : 'Target exceeds maximum possible GPA (10.0) given past credits.'}
            </p>
          </div>
        </div>

        {/* Tactical roadmap */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-base">Recommended Semester-by-Semester Roadmap</h3>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-brand-600 uppercase">Phase 1 (Current Term)</span>
                <h4 className="font-bold text-slate-900 text-sm">Semester 6 Strategy</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Secure 'O' / 'A+' grades in High-Credit subjects: Algorithms (4 cr) & Machine Learning (4 cr).
                </p>
              </div>
              <Badge variant="blue" size="md">Target SGPA: 8.90</Badge>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase">Phase 2</span>
                <h4 className="font-bold text-slate-900 text-sm">Semester 7 Electives</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Pick departmental electives aligning with your strongest performance domains (Cloud Systems & Networks).
                </p>
              </div>
              <Badge variant="green" size="md">Target SGPA: 9.00</Badge>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase">Phase 3</span>
                <h4 className="font-bold text-slate-900 text-sm">Semester 8 Capstone Project</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  High-credit final year capstone project (10 credits) offers highest mathematical leverage for GPA boost.
                </p>
              </div>
              <Badge variant="purple" size="md">Target SGPA: 9.20</Badge>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CgpaImprovement;
