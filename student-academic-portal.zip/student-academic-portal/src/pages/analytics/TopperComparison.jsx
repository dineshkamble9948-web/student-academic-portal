import React, { useState, useEffect, useCallback } from 'react';
import PageHeader from '../../components/layout/PageHeader';
import ChartCard from '../../components/common/ChartCard';
import SubjectBarChart from '../../components/charts/SubjectBarChart';
import PerformanceTrendLineChart from '../../components/charts/PerformanceTrendLineChart';
import Badge from '../../components/common/Badge';
import { Trophy, TrendingUp, AlertCircle, CheckCircle, Award, User, RefreshCw, Filter } from 'lucide-react';
import academicService from '../../services/academicService';
import { useAuth } from '../../context/AuthContext';
import { subjectPerformanceComparison, semesterTrendComparison } from '../../data/mockAnalyticsData';

export const TopperComparison = () => {
  const { user } = useAuth();
  const [selectedSemester, setSelectedSemester] = useState(user?.semester || 5);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [comparisonData, setComparisonData] = useState(subjectPerformanceComparison);
  const [toppersList, setToppersList] = useState([]);

  const fetchTopperData = useCallback(async () => {
    setLoading(true);
    setApiError(null);

    try {
      const [compRes, topperRes] = await Promise.all([
        academicService.getComparison(selectedSemester),
        academicService.getToppers(selectedSemester, user?.branch || 'CSE')
      ]);

      if (compRes?.comparison && Array.isArray(compRes.comparison) && compRes.comparison.length > 0) {
        setComparisonData(compRes.comparison.map((c) => ({
          subjectCode: c.subjectCode,
          subjectName: c.subjectName,
          studentScore: c.studentMarks?.total ?? c.studentMarks?.percentage ?? 80,
          classAverage: c.classBenchmark?.total ?? 70,
          topScore: c.highestClassScore ?? 96
        })));
      } else {
        setComparisonData(subjectPerformanceComparison);
      }

      if (topperRes?.toppers && Array.isArray(topperRes.toppers)) {
        setToppersList(topperRes.toppers);
      }
    } catch (err) {
      console.warn('[TopperComparison] Fetch issue:', err.message);
      setApiError(err.message || 'Unable to sync live topper benchmarks from server. Showing cached session records.');
      setComparisonData(subjectPerformanceComparison);
    } finally {
      setLoading(false);
    }
  }, [selectedSemester, user?.branch]);

  useEffect(() => {
    fetchTopperData();
  }, [fetchTopperData]);

  const studentCgpa = user?.stats?.cgpa || 8.42;
  const classAvgSgpa = 7.65;
  const topScorerSgpa = 9.85;

  return (
    <div className="space-y-6">
      <PageHeader
        category="Comparative Analytics"
        title="Topper Benchmark & Gap Analysis"
        description="Side-by-side comparative benchmarking against Section Toppers and Department percentile leaders."
      />

      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={fetchTopperData}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* Filter and Status Bar */}
      <div className="flex items-center justify-between bg-white p-3.5 rounded-xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <Filter className="w-4 h-4 text-brand-600" />
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Semester:</span>
          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(Number(e.target.value))}
            className="text-xs rounded-lg border border-slate-300 py-1 px-2.5 font-semibold text-slate-800 bg-slate-50 focus:border-brand-500 focus:outline-none"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
              <option key={s} value={s}>Semester {s}</option>
            ))}
          </select>
        </div>

        {loading && (
          <span className="flex items-center gap-1.5 text-xs text-brand-600 animate-pulse">
            <RefreshCw className="w-3 h-3 animate-spin" /> Syncing benchmarks...
          </span>
        )}
      </div>

      {/* Highlights / Diagnostic summary banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Student card (Blue) */}
        <div className="bg-blue-50/70 border-2 border-blue-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-xs uppercase tracking-wider">
              <span className="w-3 h-3 rounded-full bg-[#2563EB]" />
              <span>Your Profile (Student)</span>
            </div>
            <Badge variant="blue" size="sm">You</Badge>
          </div>
          <p className="text-3xl font-extrabold text-blue-900 mt-2 font-mono">{Number(studentCgpa).toFixed(2)} CGPA</p>
          <p className="text-xs text-blue-700 mt-1 font-medium">Class Rank: #14 of 120 ({user?.section || 'CSE - 6A'})</p>
        </div>

        {/* Class Average card (Green) */}
        <div className="bg-emerald-50/70 border-2 border-emerald-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs uppercase tracking-wider">
              <span className="w-3 h-3 rounded-full bg-[#10B981]" />
              <span>Class Average Benchmark</span>
            </div>
            <Badge variant="green" size="sm">Average</Badge>
          </div>
          <p className="text-3xl font-extrabold text-emerald-900 mt-2 font-mono">{classAvgSgpa.toFixed(2)} SGPA</p>
          <p className="text-xs text-emerald-700 mt-1 font-medium">Your positive delta: +{(studentCgpa - classAvgSgpa).toFixed(2)} SGPA</p>
        </div>

        {/* Top Scorer card (Red) */}
        <div className="bg-rose-50/70 border-2 border-rose-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-900 font-bold text-xs uppercase tracking-wider">
              <span className="w-3 h-3 rounded-full bg-[#EF4444]" />
              <span>Top Scorer (Class Rank #1)</span>
            </div>
            <Badge variant="red" size="sm">Topper</Badge>
          </div>
          <p className="text-3xl font-extrabold text-rose-900 mt-2 font-mono">{topScorerSgpa.toFixed(2)} SGPA</p>
          <p className="text-xs text-rose-700 mt-1 font-medium">Gap to 1st Rank: {(topScorerSgpa - studentCgpa).toFixed(2)} SGPA</p>
        </div>
      </div>

      {/* Main Comparative Bar Chart */}
      <ChartCard
        title="Subject Score Comparison vs Topper & Class Average"
        subtitle="Identifying subjects with the largest gap to the top scorer (Red) and ahead of class average (Green)"
        showStandardLegend={true}
      >
        <SubjectBarChart data={comparisonData} height={340} />
      </ChartCard>

      {/* Semester Progression Comparison Line Chart */}
      <ChartCard
        title="Historical Semester-wise Progress vs Toppers"
        subtitle="Tracking multi-semester SGPA trajectories: Student (Blue), Class Average (Green), Top Scorer (Red)"
        showStandardLegend={true}
      >
        <PerformanceTrendLineChart data={semesterTrendComparison} height={320} />
      </ChartCard>

      {/* Diagnostic Gap Breakdown & Strengths */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Gap areas */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-500" />
            <h3 className="font-bold text-slate-900 text-sm">Primary Gap Opportunities (Topper Delta)</h3>
          </div>
          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-rose-50/70 rounded-xl border border-rose-100">
              <div className="flex justify-between font-bold text-rose-900">
                <span>CS604: Compiler Design</span>
                <span>Gap: -27%</span>
              </div>
              <p className="text-rose-700 mt-1 leading-relaxed">
                Your score: 65% | Topper: 92%. Focus on LR parsing and syntax-directed translation matrices.
              </p>
            </div>
            <div className="p-3.5 bg-amber-50/70 rounded-xl border border-amber-100">
              <div className="flex justify-between font-bold text-amber-900">
                <span>CS603: Computer Networks</span>
                <span>Gap: -22%</span>
              </div>
              <p className="text-amber-700 mt-1 leading-relaxed">
                Your score: 72% | Topper: 94%. Practice subnetting numericals and routing protocol convergence exercises.
              </p>
            </div>
          </div>
        </div>

        {/* Strengths */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-500" />
            <h3 className="font-bold text-slate-900 text-sm">Competitive Strengths (Parity with Topper)</h3>
          </div>
          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-100">
              <div className="flex justify-between font-bold text-emerald-900">
                <span>CS606L: Web Tech Lab</span>
                <span>Gap: -4% (Near Topper)</span>
              </div>
              <p className="text-emerald-700 mt-1 leading-relaxed">
                Your score: 95% | Topper: 99%. Exemplary performance in full-stack architecture and implementation.
              </p>
            </div>
            <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-100">
              <div className="flex justify-between font-bold text-blue-900">
                <span>CS605: Machine Learning</span>
                <span>Gap: -5% (Near Topper)</span>
              </div>
              <p className="text-blue-700 mt-1 leading-relaxed">
                Your score: 92% | Topper: 97%. Strong algorithmic foundation and regression modeling accuracy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopperComparison;
