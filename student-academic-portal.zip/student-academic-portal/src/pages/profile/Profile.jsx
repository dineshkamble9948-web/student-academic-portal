import React from 'react';
import PageHeader from '../../components/layout/PageHeader';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import { User, Mail, GraduationCap, Building2, Phone, Calendar, Award, BookOpen, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Profile = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <PageHeader
        category="Student Profile"
        title="Student Identity & Academic Credentials"
        description="Official institutional profile and university records information."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: ID Card */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm flex flex-col items-center text-center space-y-4">
          <div className="relative">
            <img
              src={user?.avatar}
              alt={user?.name}
              className="w-28 h-28 rounded-2xl object-cover ring-4 ring-brand-100 shadow-md"
            />
            <span className="absolute bottom-0 right-0 p-1.5 bg-emerald-500 rounded-full ring-2 ring-white" title="Active Student" />
          </div>

          <div>
            <h2 className="text-xl font-bold text-slate-900">{user?.name}</h2>
            <p className="text-xs text-brand-600 font-semibold font-mono mt-0.5">{user?.rollNumber}</p>
            <p className="text-xs text-slate-500 mt-1">{user?.department}</p>
          </div>

          <div className="w-full pt-3 border-t border-slate-100 space-y-2 text-xs text-left">
            <div className="flex items-center gap-2 text-slate-600">
              <Mail className="w-4 h-4 text-slate-400" />
              <span className="truncate">{user?.email}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <GraduationCap className="w-4 h-4 text-slate-400" />
              <span>{user?.degree} • Semester {user?.semester} ({user?.section})</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Academic Year {user?.academicYear}</span>
            </div>
          </div>

          <div className="w-full pt-2">
            <Badge variant="green" size="md" className="w-full justify-center">
              Verified University Matriculation
            </Badge>
          </div>
        </div>

        {/* Right: Academic Mentor & Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Academic Mentor Card */}
          <div className="bg-white rounded-xl border border-slate-200/80 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-brand-600" />
                <h3 className="font-bold text-slate-900 text-base">Assigned Faculty Academic Advisor</h3>
              </div>
              <Badge variant="blue" size="sm">Advisor</Badge>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="font-bold text-slate-800 text-sm">{user?.mentor?.name}</h4>
                <p className="text-xs text-slate-500">{user?.mentor?.designation}</p>
                <p className="text-xs text-slate-400 mt-1">{user?.mentor?.cabin}</p>
              </div>
              <Button variant="secondary" size="sm">
                Message Advisor
              </Button>
            </div>
          </div>

          {/* Academic Metrics Summary */}
          <div className="bg-white rounded-xl border border-slate-200/80 p-6 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-3">
              Degree Audit & Performance Index
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase">CGPA</p>
                <p className="text-xl font-bold text-blue-600 mt-1">{user?.stats?.cgpa}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase">Class Rank</p>
                <p className="text-xl font-bold text-slate-800 mt-1">#{user?.stats?.classRank}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase">Attendance</p>
                <p className="text-xl font-bold text-emerald-600 mt-1">{user?.stats?.attendanceRate}%</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase">Credits</p>
                <p className="text-xl font-bold text-slate-800 mt-1">{user?.stats?.totalCreditsCompleted}</p>
              </div>
            </div>

            <div className="pt-2">
              <div className="flex justify-between text-xs text-slate-600 mb-1 font-medium">
                <span>Degree Credit Progress (B.Tech 160 Credits)</span>
                <span>70% Completed</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div className="bg-brand-600 h-full rounded-full" style={{ width: '70%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
