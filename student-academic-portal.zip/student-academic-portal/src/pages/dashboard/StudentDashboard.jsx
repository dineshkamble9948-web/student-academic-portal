import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Award,
  Trophy,
  CheckCircle2,
  BookOpen,
  Calendar,
  Clock,
  ArrowUpRight,
  Sparkles,
  Download,
  AlertTriangle,
  ChevronRight,
  Users2,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import dashboardService from '../../services/dashboardService';
import StatCard from '../../components/common/StatCard';
import ChartCard from '../../components/common/ChartCard';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import DataTable from '../../components/common/DataTable';
import SubjectBarChart from '../../components/charts/SubjectBarChart';
import PerformanceTrendLineChart from '../../components/charts/PerformanceTrendLineChart';

// Initial verified fallback data
import {
  subjectPerformanceComparison as initialSubjectsComparison,
  semesterTrendComparison as initialSemesterTrend,
  studyPlannerSchedule
} from '../../data/mockAnalyticsData';
import {
  currentSemesterSubjects as initialCourses,
  upcomingTasks as initialTasks,
  seniorMentors
} from '../../data/mockStudentData';

export const StudentDashboard = () => {
  const { user, setUser } = useAuth();

  const [isLoading, setIsLoading] = useState(true);
  const [apiError, setApiError] = useState(null);

  // Live dashboard data states with defensive initial fallbacks
  const [subjectsComparison, setSubjectsComparison] = useState(initialSubjectsComparison);
  const [semesterTrend, setSemesterTrend] = useState(initialSemesterTrend);
  const [courses, setCourses] = useState(initialCourses);
  const [tasks, setTasks] = useState(initialTasks);

  // Fetch real verified dashboard analytics from backend
  const fetchDashboard = useCallback(async () => {
    setIsLoading(true);
    setApiError(null);

    try {
      const data = await dashboardService.getDashboardData();

      if (data) {
        // Sync student profile metrics if updated on backend
        if (data.student) {
          setUser((prev) => ({ ...(prev || {}), ...data.student }));
        }

        if (Array.isArray(data.subjectPerformanceComparison) && data.subjectPerformanceComparison.length > 0) {
          setSubjectsComparison(data.subjectPerformanceComparison);
        }

        if (Array.isArray(data.semesterTrendComparison) && data.semesterTrendComparison.length > 0) {
          setSemesterTrend(data.semesterTrendComparison);
        }

        if (Array.isArray(data.currentSemesterCourses) && data.currentSemesterCourses.length > 0) {
          setCourses(data.currentSemesterCourses);
        }

        if (Array.isArray(data.upcomingTasks) && data.upcomingTasks.length > 0) {
          setTasks(data.upcomingTasks);
        }
      }
    } catch (err) {
      console.warn('[StudentDashboard] Backend fetch issue:', err.message);
      setApiError(err.message || 'Unable to sync live analytics from server. Showing cached session records.');
      // Keep verified initial mock data so dashboard remains fully operational
    } finally {
      setIsLoading(false);
    }
  }, [setUser]);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  // Subject table columns definition
  const subjectColumns = [
    {
      header: 'Subject & Code',
      accessor: 'name',
      render: (row) => (
        <div>
          <span className="font-semibold text-slate-900 block">{row.name || 'Untitled Course'}</span>
          <span className="text-xs text-slate-500 font-mono">
            {row.code || 'N/A'} • {row.credits ?? 0} Credits
          </span>
        </div>
      ),
    },
    {
      header: 'Faculty',
      accessor: 'faculty',
      cellClassName: 'text-slate-600',
      render: (row) => <span>{row.faculty || 'Department Faculty'}</span>,
    },
    {
      header: 'Attendance',
      accessor: 'attendance',
      render: (row) => {
        const attendance = row.attendance ?? 0;
        const isWarning = attendance < 80;
        return (
          <div className="flex items-center gap-2">
            <div className="w-16 bg-slate-200 rounded-full h-2 overflow-hidden">
              <div
                className={`h-full rounded-full ${isWarning ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style={{ width: `${Math.min(100, Math.max(0, attendance))}%` }}
              />
            </div>
            <span className={`text-xs font-semibold ${isWarning ? 'text-amber-700' : 'text-slate-700'}`}>
              {attendance}%
            </span>
          </div>
        );
      },
    },
    {
      header: 'Internal Marks',
      accessor: 'internalMarks',
      render: (row) => (
        <span className="font-semibold text-slate-800">
          {row.internalMarks ?? 0} <span className="text-slate-400 font-normal text-xs">/ 50</span>
        </span>
      ),
    },
    {
      header: 'Benchmark Status',
      accessor: 'status',
      render: (row) => {
        const variant =
          row.riskLevel === 'Low'
            ? 'green'
            : row.riskLevel === 'Medium'
            ? 'amber'
            : 'red';
        return (
          <Badge variant={variant} size="sm" dot>
            {row.status || 'Active'}
          </Badge>
        );
      },
    },
  ];

  const studentStats = user?.stats || {
    cgpa: 8.42,
    cgpaScale: 10.0,
    targetCgpa: 9.0,
    classRank: 14,
    totalStudents: 120,
    totalCreditsCompleted: 112,
    totalCreditsRequired: 160,
    attendanceRate: 88.5,
  };

  return (
    <div className="space-y-6">
      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={fetchDashboard}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* Top Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-brand-900 via-brand-800 to-slate-900 p-6 sm:p-8 text-white shadow-lg">
        {/* Decorative Background Elements */}
        <div className="absolute -right-12 -top-12 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl pointer-events-none" />
        <div className="absolute right-32 -bottom-12 h-48 w-48 rounded-full bg-blue-400/10 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-white/90 text-xs font-medium backdrop-blur-md border border-white/10">
                <Sparkles className="w-3.5 h-3.5 text-brand-300" />
                Academic Term {user?.academicYear || '2023 - 2024'}
              </span>
              <span className="px-3 py-1 rounded-full bg-brand-500/20 text-brand-200 text-xs font-medium border border-brand-400/20">
                Semester {user?.semester || 6} ({user?.section || 'CSE - 6A'})
              </span>
              {isLoading && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-500/30 text-blue-200 text-xs font-medium animate-pulse">
                  <RefreshCw className="w-3 h-3 animate-spin" /> Syncing data...
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name || 'Student'}! 👋
            </h1>

            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Your overall projected CGPA is <span className="font-semibold text-white">8.85</span> for this semester. You are currently on track to achieve your goal of <span className="font-semibold text-brand-200">9.00 CGPA</span>. Keep up the consistent focus in Compiler Design!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Link to="/planner">
              <Button
                variant="primary"
                className="bg-white text-brand-900 hover:bg-slate-100 shadow-md font-semibold"
                icon={Calendar}
              >
                Today's Planner
              </Button>
            </Link>
            <Link to="/analytics/topper-comparison">
              <Button
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
                icon={Trophy}
              >
                Compare Topper
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <StatCard
          title="Current CGPA"
          value={studentStats.cgpa ? `${studentStats.cgpa} / 10.0` : '8.42'}
          subtext={`Target: ${studentStats.targetCgpa || 9.0} CGPA`}
          icon={Award}
          iconColor="text-blue-600"
          iconBg="bg-blue-50"
          trend="+0.15 this sem"
          trendType="up"
        />

        <StatCard
          title="Class Rank Standing"
          value={`#${studentStats.classRank || 14} of ${studentStats.totalStudents || 120}`}
          subtext={user?.section || 'CSE Section 6A'}
          icon={Trophy}
          iconColor="text-amber-600"
          iconBg="bg-amber-50"
          trend="Top 11.6%"
          trendType="up"
        />

        <StatCard
          title="Semester Attendance"
          value={`${studentStats.attendanceRate || 88.5}%`}
          subtext="Min. 75% required"
          icon={CheckCircle2}
          iconColor="text-emerald-600"
          iconBg="bg-emerald-50"
          trend="Safe Zone"
          trendType="up"
        />

        <StatCard
          title="Degree Credits"
          value={`${studentStats.totalCreditsCompleted || 112} / ${studentStats.totalCreditsRequired || 160}`}
          subtext="48 credits remaining"
          icon={BookOpen}
          iconColor="text-indigo-600"
          iconBg="bg-indigo-50"
          trend="70% Completed"
          trendType="neutral"
        />
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Comparison Bar Chart */}
        <ChartCard
          title="Subject Marks vs Class Benchmark"
          subtitle="Real-time comparative scores across all enrolled 6th-semester subjects"
          showStandardLegend={true}
          infoTooltip="Color legend: Blue = Logged-in Student, Green = Class Average, Red = Class Top Scorer"
          actions={
            <Link
              to="/analytics/topper-comparison"
              className="text-xs font-semibold text-brand-600 hover:text-brand-700 inline-flex items-center gap-1"
            >
              Full Analytics <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          }
        >
          <SubjectBarChart data={subjectsComparison} height={310} />
        </ChartCard>

        {/* SGPA & CGPA Trend Line Chart */}
        <ChartCard
          title="Academic SGPA Progression Trend"
          subtitle="Historical semester performance comparing your trajectory with benchmarks"
          showStandardLegend={true}
          infoTooltip="Track your semester GPA trend against class average and topper benchmarks"
          actions={
            <Link
              to="/analytics/cgpa-improvement"
              className="text-xs font-semibold text-brand-600 hover:text-brand-700 inline-flex items-center gap-1"
            >
              Improvement Plan <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          }
        >
          <PerformanceTrendLineChart data={semesterTrend} height={310} />
        </ChartCard>
      </div>

      {/* Main Content Split: Subjects Table & Side Widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left (2 Cols): Enrolled Subjects Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Current Semester Courses (Sem {user?.semester || 6})
              </h2>
              <p className="text-xs text-slate-500">
                Detailed view of internal marks, attendance threshold, and risk assessment
              </p>
            </div>
            <Link to="/analytics/subjects">
              <Button variant="secondary" size="sm">
                View All Details
              </Button>
            </Link>
          </div>

          <DataTable
            columns={subjectColumns}
            data={courses}
            keyField="code"
          />
        </div>

        {/* Right (1 Col): Deadlines & Mentorship Snippet */}
        <div className="space-y-6">
          {/* Upcoming Deadlines Card */}
          <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-brand-600" />
                <h3 className="text-sm font-bold text-slate-900">Upcoming Submissions</h3>
              </div>
              <Link
                to="/assignments"
                className="text-xs font-semibold text-brand-600 hover:underline"
              >
                View all ({tasks.length})
              </Link>
            </div>

            <div className="space-y-3">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  className="p-3 rounded-lg border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-xs font-bold text-slate-800 line-clamp-1">
                      {task.title}
                    </p>
                    <Badge
                      variant={task.priority === 'High' ? 'red' : 'blue'}
                      size="sm"
                    >
                      {task.priority || 'Normal'}
                    </Badge>
                  </div>

                  <p className="text-[11px] text-slate-500 mt-1">
                    {task.course} • Due <span className="font-semibold text-slate-700">{task.dueDate}</span>
                  </p>

                  <div className="mt-2 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">Status: {task.status || 'Active'}</span>
                    <span className="font-semibold text-slate-700">{task.progress ?? 0}%</span>
                  </div>
                  <div className="mt-1 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-brand-600 h-full rounded-full"
                      style={{ width: `${Math.min(100, Math.max(0, task.progress ?? 0))}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Senior Mentorship Feature Spotlight */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 rounded-xl border border-blue-100 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-brand-800 font-bold text-sm">
                <Users2 className="w-4 h-4 text-brand-600" />
                <span>Senior Mentorship</span>
              </div>
              <Badge variant="blue" size="sm">Active</Badge>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Connect with high-achieving seniors placed at top tech companies for resume reviews, subject strategies, and mock interviews.
            </p>

            {seniorMentors.slice(0, 1).map((mentor) => (
              <div
                key={mentor.id}
                className="bg-white rounded-lg p-3 border border-blue-200/60 shadow-xs flex items-center gap-3"
              >
                <img
                  src={mentor.avatar}
                  alt={mentor.name}
                  className="w-10 h-10 rounded-full object-cover ring-1 ring-blue-300"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-900 truncate">{mentor.name}</p>
                  <p className="text-[11px] text-brand-600 font-medium truncate">{mentor.companyPlacement}</p>
                  <p className="text-[10px] text-slate-400 truncate">{mentor.availability}</p>
                </div>
              </div>
            ))}

            <Link to="/mentorship" className="block pt-1">
              <Button variant="outline" size="sm" className="w-full bg-white">
                Explore All Mentors & Book Slot
              </Button>
            </Link>
          </div>

          {/* Smart Study Planner Quick Link */}
          <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <h3 className="text-sm font-bold text-slate-900">Today's Smart Study Focus</h3>
              </div>
              <span className="text-[11px] text-slate-400">AI Planned</span>
            </div>

            <div className="p-3 rounded-lg bg-amber-50/60 border border-amber-200/60 text-xs">
              <div className="flex items-center justify-between font-bold text-amber-900">
                <span>Compiler Design</span>
                <span>04:30 PM - 06:00 PM</span>
              </div>
              <p className="text-amber-800 mt-1 text-[11px]">
                Topic: LL(1) & LR Parsing Tables
              </p>
              <p className="text-[10px] text-amber-700/80 mt-1 italic">
                Reason: Quiz score was 65% (below your 85% benchmark)
              </p>
            </div>

            <Link to="/planner" className="block">
              <Button variant="secondary" size="sm" className="w-full">
                Open Smart Planner Schedule
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
