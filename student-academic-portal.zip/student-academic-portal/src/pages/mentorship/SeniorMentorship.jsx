import React, { useState, useEffect, useCallback } from 'react';
import PageHeader from '../../components/layout/PageHeader';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Modal from '../../components/common/Modal';
import {
  Users2,
  Star,
  Calendar,
  MessageSquare,
  CheckCircle,
  Video,
  Search,
  Filter,
  Check,
  X,
  Clock,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import mentorshipService from '../../services/mentorshipService';
import { useAuth } from '../../context/AuthContext';
import { seniorMentors } from '../../data/mockStudentData';

export const SeniorMentorship = () => {
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState('discovery'); // 'discovery' | 'myRequests'
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [mentors, setMentors] = useState([]);
  const [myRequests, setMyRequests] = useState([]);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('All');
  const [femaleMentorOnly, setFemaleMentorOnly] = useState(false);

  // Request Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [requestFormData, setRequestFormData] = useState({
    subjectName: '',
    subjectId: '',
    topic: '',
    message: '',
    femaleMentorOnly: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackBanner, setFeedbackBanner] = useState(null);

  // Fetch mentors & requests
  const loadData = useCallback(async () => {
    setLoading(true);
    setApiError(null);

    try {
      const [mentorRes, reqRes] = await Promise.all([
        mentorshipService.getMentors({ femaleOnly: femaleMentorOnly }),
        mentorshipService.getMyRequests()
      ]);

      if (mentorRes?.mentors && Array.isArray(mentorRes.mentors) && mentorRes.mentors.length > 0) {
        setMentors(mentorRes.mentors);
      } else {
        // Fallback to verified mock mentors if database is unseeded
        setMentors(
          seniorMentors.map((m) => ({
            mentorId: m.id,
            id: m.id,
            name: m.name,
            rollNumber: m.rollNumber || '20CS055',
            email: `${m.name.toLowerCase().replace(' ', '.')}@college.edu`,
            gender: m.name.includes('Priya') || m.name.includes('Sneha') ? 'Female' : 'Male',
            branch: m.branch || 'CSE',
            year: 4,
            previousSemCgpa: 9.35,
            rating: m.rating || 4.9,
            availabilityStatus: true,
            availableDays: ['Monday', 'Wednesday', 'Friday', 'Saturday'],
            companyPlacement: m.companyPlacement,
            avatar: m.avatar,
            remainingSlots: 3,
            subjectExpertise: m.domains.map((dom) => ({
              subjectCode: dom.slice(0, 5).toUpperCase(),
              subjectName: dom,
              proficiencyLevel: 'Expert',
              gradeAcquired: 'O'
            }))
          }))
        );
      }

      if (reqRes?.requests && Array.isArray(reqRes.requests)) {
        setMyRequests(reqRes.requests);
      }
    } catch (err) {
      console.warn('[SeniorMentorship] Fetch error:', err.message);
      setApiError(err.message || 'Unable to sync live mentors from server. Showing cached session mentors.');
      // Keep verified initial mock dataset
      setMentors(
        seniorMentors.map((m) => ({
          mentorId: m.id,
          id: m.id,
          name: m.name,
          rollNumber: m.rollNumber || '20CS055',
          email: `${m.name.toLowerCase().replace(' ', '.')}@college.edu`,
          gender: m.name.includes('Priya') || m.name.includes('Sneha') ? 'Female' : 'Male',
          branch: m.branch || 'CSE',
          year: 4,
          previousSemCgpa: 9.35,
          rating: m.rating || 4.9,
          availabilityStatus: true,
          availableDays: ['Monday', 'Wednesday', 'Friday', 'Saturday'],
          companyPlacement: m.companyPlacement,
          avatar: m.avatar,
          remainingSlots: 3,
          subjectExpertise: m.domains.map((dom) => ({
            subjectCode: dom.slice(0, 5).toUpperCase(),
            subjectName: dom,
            proficiencyLevel: 'Expert',
            gradeAcquired: 'O'
          }))
        }))
      );
    } finally {
      setLoading(false);
    }
  }, [femaleMentorOnly]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const domains = ['All', 'Database Systems', 'Operating Systems', 'Machine Learning', 'Competitive Programming', 'Full Stack Development'];

  // Filter mentors based on search & domain
  const filteredMentors = mentors.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.subjectExpertise?.some((s) => s.subjectName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      m.companyPlacement?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDomain =
      selectedDomain === 'All' ||
      m.subjectExpertise?.some((s) => s.subjectName.toLowerCase().includes(selectedDomain.toLowerCase()));

    const matchesGender = !femaleMentorOnly || m.gender === 'Female';

    return matchesSearch && matchesDomain && matchesGender;
  });

  const handleOpenRequestModal = (mentor) => {
    setSelectedMentor(mentor);
    const firstSub = mentor.subjectExpertise?.[0];
    setRequestFormData({
      subjectName: firstSub?.subjectName || 'Database Systems',
      subjectId: firstSub?.subject || firstSub?._id || '',
      topic: '',
      message: '',
      femaleMentorOnly: mentor.gender === 'Female' && femaleMentorOnly
    });
    setIsModalOpen(true);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!selectedMentor) return;

    setIsSubmitting(true);
    setFeedbackBanner(null);

    try {
      const targetSub = selectedMentor.subjectExpertise?.find(
        (s) => s.subjectName === requestFormData.subjectName
      ) || selectedMentor.subjectExpertise?.[0];

      const payload = {
        seniorId: selectedMentor.mentorId || selectedMentor.id || selectedMentor._id,
        subjectId: targetSub?.subject || targetSub?._id || undefined,
        topic: requestFormData.topic.trim(),
        message: requestFormData.message.trim(),
        femaleMentorOnly: requestFormData.femaleMentorOnly
      };

      const res = await mentorshipService.sendRequest(payload);

      // Add to local requests list immediately
      const newReq = {
        id: res.data?._id || res.request?.id || `req-${Date.now()}`,
        _id: res.data?._id || `req-${Date.now()}`,
        senior: {
          name: selectedMentor.name,
          rollNumber: selectedMentor.rollNumber,
          gender: selectedMentor.gender,
          branch: selectedMentor.branch
        },
        subject: {
          name: requestFormData.subjectName,
          subjectCode: targetSub?.subjectCode || 'CS501'
        },
        topic: requestFormData.topic,
        message: requestFormData.message,
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      setMyRequests([newReq, ...myRequests]);
      setIsModalOpen(false);
      setFeedbackBanner({
        type: 'success',
        text: `Mentorship request sent to ${selectedMentor.name}! Track progress under 'My Requests'.`
      });
      setTimeout(() => setFeedbackBanner(null), 6000);
    } catch (err) {
      setFeedbackBanner({
        type: 'error',
        text: err.message || 'Failed to submit request. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancelRequest = (requestId) => {
    setMyRequests(
      myRequests.map((r) =>
        r.id === requestId || r._id === requestId ? { ...r, status: 'cancelled' } : r
      )
    );
    setFeedbackBanner({
      type: 'info',
      text: 'Mentorship request cancelled successfully.'
    });
    setTimeout(() => setFeedbackBanner(null), 4000);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        category="Senior Mentorship Hub"
        title="Peer-to-Peer & Senior Academic Guidance"
        description="Book 1-on-1 guidance sessions with top-ranked final-year seniors and industry-placed student mentors."
        actions={
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('discovery')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeTab === 'discovery'
                  ? 'bg-white text-brand-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Discover Mentors ({filteredMentors.length})
            </button>
            <button
              onClick={() => setActiveTab('myRequests')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'myRequests'
                  ? 'bg-white text-brand-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              My Requests
              {myRequests.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-brand-600 text-white">
                  {myRequests.filter((r) => r.status === 'pending' || r.status === 'accepted').length}
                </span>
              )}
            </button>
          </div>
        }
      />

      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={loadData}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* Feedback Banner */}
      {feedbackBanner && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-center justify-between gap-3 animate-fadeIn ${
            feedbackBanner.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : feedbackBanner.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-blue-50 border-blue-200 text-blue-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackBanner.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span className="font-semibold">{feedbackBanner.text}</span>
          </div>
          <button onClick={() => setFeedbackBanner(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {activeTab === 'discovery' ? (
        <>
          {/* Search, Domain Filters & Female Mentor Preference Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Search input */}
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search mentors by name, subject (e.g. DBMS, OS) or placement..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-300 py-2 pl-10 pr-3 font-medium text-slate-800 placeholder-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
                />
              </div>

              {/* Female Mentor Preference Checkbox Toggle */}
              <label className="inline-flex items-center gap-2.5 px-3 py-2 rounded-xl bg-purple-50/70 border border-purple-200 cursor-pointer hover:bg-purple-100/50 transition-colors shrink-0">
                <input
                  type="checkbox"
                  checked={femaleMentorOnly}
                  onChange={(e) => setFemaleMentorOnly(e.target.checked)}
                  className="rounded text-purple-600 focus:ring-purple-500 h-4 w-4"
                />
                <span className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-purple-600" />
                  Female Mentor Preference Only
                </span>
              </label>
            </div>

            {/* Domain Pills */}
            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
                Domain:
              </span>
              {domains.map((dom) => (
                <button
                  key={dom}
                  onClick={() => setSelectedDomain(dom)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    selectedDomain === dom
                      ? 'bg-brand-600 text-white shadow-xs'
                      : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {dom}
                </button>
              ))}
            </div>
          </div>

          {/* Mentors Cards Grid */}
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-400 text-xs">
              <RefreshCw className="w-6 h-6 animate-spin text-brand-600 mb-2" />
              <span>Loading registered senior mentors...</span>
            </div>
          ) : filteredMentors.length === 0 ? (
            <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 p-8">
              <Users2 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-800">No matching mentors found</p>
              <p className="text-xs text-slate-500 mt-1">Try resetting the domain filter or search keyword.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMentors.map((mentor) => {
                const isAvailable = mentor.availabilityStatus;
                const mentorKey = mentor.mentorId || mentor.id || mentor._id;

                return (
                  <div
                    key={mentorKey}
                    className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs space-y-4 hover:shadow-md transition-shadow flex flex-col justify-between"
                  >
                    <div className="space-y-3.5">
                      {/* Senior Profile Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={mentor.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80'}
                            alt={mentor.name}
                            className="w-14 h-14 rounded-2xl object-cover ring-2 ring-brand-100 shadow-xs"
                          />
                          <div>
                            <h3 className="font-bold text-slate-900 text-base leading-tight">
                              {mentor.name}
                            </h3>
                            <p className="text-xs text-brand-600 font-semibold mt-0.5">
                              {mentor.companyPlacement || 'Senior Academic Peer'}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              {mentor.branch} • Year {mentor.year} • {mentor.gender}
                            </p>
                          </div>
                        </div>

                        <Badge variant={isAvailable ? 'green' : 'amber'} size="sm" dot>
                          {isAvailable ? 'Available' : 'At Capacity'}
                        </Badge>
                      </div>

                      {/* CGPA & Ratings */}
                      <div className="flex items-center justify-between text-xs p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="flex items-center gap-1 font-bold text-slate-800">
                          <Award className="w-4 h-4 text-blue-600" />
                          <span>CGPA: {Number(mentor.previousSemCgpa || 9.2).toFixed(2)}</span>
                        </div>
                        <div className="flex items-center gap-1 text-amber-500 font-bold">
                          <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                          <span>{mentor.rating || 4.9}</span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-medium">
                          Slots: {mentor.remainingSlots ?? 3} left
                        </span>
                      </div>

                      {/* Subjects Can Mentor In */}
                      <div>
                        <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                          Mentoring Subjects & Expertise:
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {mentor.subjectExpertise?.map((sub, i) => (
                            <span
                              key={i}
                              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/60"
                            >
                              {sub.subjectName}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Schedule Availability Days */}
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                        <span className="truncate">
                          Days: {mentor.availableDays?.join(', ') || 'Mon, Wed, Fri'}
                        </span>
                      </div>
                    </div>

                    {/* Action button */}
                    <div className="pt-2">
                      <Button
                        variant={isAvailable ? 'primary' : 'secondary'}
                        size="md"
                        disabled={!isAvailable}
                        className="w-full font-semibold shadow-xs"
                        icon={Video}
                        onClick={() => handleOpenRequestModal(mentor)}
                      >
                        {isAvailable ? 'Request Mentorship Session' : 'Currently at Capacity'}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      ) : (
        /* My Mentorship Requests View */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Your Submitted Mentorship Requests</h3>
              <p className="text-xs text-slate-500">
                Track status updates from senior mentors, session schedule times, and virtual meet links.
              </p>
            </div>
            <Button variant="outline" size="sm" icon={RefreshCw} onClick={loadData}>
              Refresh
            </Button>
          </div>

          {myRequests.length === 0 ? (
            <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 p-8">
              <MessageSquare className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-800">No requests submitted yet</p>
              <p className="text-xs text-slate-500 mt-1">
                Explore available senior mentors and submit a topic guidance request.
              </p>
              <Button
                variant="primary"
                size="sm"
                className="mt-4"
                onClick={() => setActiveTab('discovery')}
              >
                Find a Senior Mentor
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {myRequests.map((req) => {
                const reqId = req.id || req._id;
                const isAccepted = req.status === 'accepted';
                const isPending = req.status === 'pending';
                const isCancelled = req.status === 'cancelled';
                const seniorName = req.senior?.name || req.mentor?.name || 'Senior Mentor';
                const subjectTitle = req.subject?.name || req.subject?.subjectCode || req.subject || 'Course Topic';

                return (
                  <div
                    key={reqId}
                    className={`p-5 rounded-2xl border transition-all ${
                      isAccepted
                        ? 'bg-emerald-50/30 border-emerald-200 shadow-xs'
                        : isCancelled
                        ? 'bg-slate-50/60 border-slate-200 opacity-70'
                        : 'bg-white border-slate-200 shadow-xs'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-900 text-sm">
                            Session with {seniorName}
                          </h4>
                          <span className="text-xs text-slate-400">
                            ({req.senior?.branch || req.mentor?.branch || 'CSE'})
                          </span>
                        </div>
                        <p className="text-xs text-brand-600 font-semibold mt-0.5">
                          {subjectTitle}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <Badge
                          variant={isAccepted ? 'green' : isPending ? 'amber' : 'slate'}
                          size="sm"
                          dot
                        >
                          {req.status?.toUpperCase()}
                        </Badge>

                        {isPending && (
                          <button
                            onClick={() => handleCancelRequest(reqId)}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors"
                          >
                            Cancel Request
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="font-bold text-slate-500 uppercase tracking-wider block">
                          Topic / Questions:
                        </span>
                        <p className="text-slate-800 font-medium mt-0.5">{req.topic}</p>
                        {req.message && (
                          <p className="text-slate-500 mt-1 italic">"{req.message}"</p>
                        )}
                      </div>

                      {/* Mentor Response if Accepted */}
                      {isAccepted && (
                        <div className="p-3 rounded-xl bg-white border border-emerald-200 space-y-2">
                          <div className="flex items-center justify-between text-emerald-800 font-semibold">
                            <span>Scheduled Session Time:</span>
                            <span className="font-bold">
                              {req.scheduledTime ? new Date(req.scheduledTime).toLocaleString() : 'Confirmed by Mentor'}
                            </span>
                          </div>
                          {req.responseNote && (
                            <p className="text-slate-600 text-[11px]">
                              <strong>Mentor note:</strong> {req.responseNote}
                            </p>
                          )}
                          {req.meetingLink && (
                            <a
                              href={req.meetingLink}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 shadow-xs"
                            >
                              <Video className="w-3.5 h-3.5" />
                              Join Google Meet Session
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      )}

                      {isPending && (
                        <div className="flex items-center gap-2 text-slate-500 text-xs italic">
                          <Clock className="w-4 h-4 text-amber-500" />
                          <span>Awaiting senior mentor confirmation. You will receive an alert once accepted.</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Request Mentorship Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Request Mentorship with ${selectedMentor?.name || ''}`}
        subtitle={`${selectedMentor?.branch} • Placement: ${selectedMentor?.companyPlacement || 'Senior'}`}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Select Subject for Mentorship <span className="text-rose-500">*</span>
            </label>
            <select
              required
              value={requestFormData.subjectName}
              onChange={(e) => {
                const sub = selectedMentor?.subjectExpertise?.find(
                  (s) => s.subjectName === e.target.value
                );
                setRequestFormData({
                  ...requestFormData,
                  subjectName: e.target.value,
                  subjectId: sub?.subject || sub?._id || ''
                });
              }}
              className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2.5 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            >
              {selectedMentor?.subjectExpertise?.map((sub, i) => (
                <option key={i} value={sub.subjectName}>
                  {sub.subjectName} ({sub.subjectCode})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Specific Topic / Problem Statement <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. BCNF Decomposition Proofs or Subnetting Numerical calculations"
              value={requestFormData.topic}
              onChange={(e) => setRequestFormData({ ...requestFormData, topic: e.target.value })}
              className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2.5 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Additional Details / Questions <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="Briefly state where you are stuck, or what you'd like to cover during the 45-min session..."
              value={requestFormData.message}
              onChange={(e) => setRequestFormData({ ...requestFormData, message: e.target.value })}
              className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            />
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
            <span>Female Mentor Preference:</span>
            <span className="font-bold text-purple-700">
              {selectedMentor?.gender === 'Female' ? 'Applied (Female Mentor)' : 'Standard Preference'}
            </span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              size="md"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="md"
              loading={isSubmitting}
              icon={Check}
            >
              Send Request to Senior
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default SeniorMentorship;
