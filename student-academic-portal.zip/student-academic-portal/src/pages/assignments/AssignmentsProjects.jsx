import React, { useState, useEffect, useCallback } from 'react';
import PageHeader from '../../components/layout/PageHeader';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import DataTable from '../../components/common/DataTable';
import Modal from '../../components/common/Modal';
import {
  FileSpreadsheet,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Filter,
  Check,
  X,
  Calendar,
  Layers,
  Award,
  BookOpen,
  Code2,
  Presentation,
  FileCheck2,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import taskService from '../../services/taskService';
import { useAuth } from '../../context/AuthContext';
import { upcomingTasks } from '../../data/mockStudentData';

export const AssignmentsProjects = () => {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'PENDING' | 'COMPLETED' | 'OVERDUE'

  // Modal State for adding assignment
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    type: 'assignment',
    subjectCode: 'CS601',
    description: '',
    dueDate: '2026-11-25',
    estimatedHours: 4,
    priority: 'medium'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  // Past submissions table records
  const pastSubmissions = [
    {
      id: 101,
      title: 'Lab 4: Socket Programming with TCP/UDP in C',
      course: 'CS603 - CNS',
      type: 'Project',
      submittedOn: 'Nov 08, 2026',
      grade: '19 / 20',
      feedback: 'Excellent socket implementation; clean code and test documentation.',
      status: 'Graded',
      score: 95
    },
    {
      id: 102,
      title: 'DBMS SQL Assignment 3: Complex Joins & Subqueries',
      course: 'CS602 - DBMS',
      type: 'Assignment',
      submittedOn: 'Nov 04, 2026',
      grade: '18 / 20',
      feedback: 'Optimized queries, well documented schema constraints.',
      status: 'Graded',
      score: 90
    },
    {
      id: 103,
      title: 'DAA Divide and Conquer Master Theorem Problem Set',
      course: 'CS601 - DAA',
      type: 'Assignment',
      submittedOn: 'Oct 29, 2026',
      grade: '20 / 20',
      feedback: 'Flawless proofs and recurrence relations analysis.',
      status: 'Graded',
      score: 100
    },
    {
      id: 104,
      title: 'Compiler Design Lexical Analyzer Presentation',
      course: 'CS604 - CD',
      type: 'Presentation',
      submittedOn: 'Oct 22, 2026',
      grade: '18 / 20',
      feedback: 'Very thorough DFA transition diagrams and tokenization explanation.',
      status: 'Graded',
      score: 90
    }
  ];

  // Fetch tasks from service
  const loadTasks = useCallback(async () => {
    setLoading(true);
    setApiError(null);

    try {
      const res = await taskService.getTasks();
      if (res?.tasks && Array.isArray(res.tasks) && res.tasks.length > 0) {
        setTasks(res.tasks);
      } else {
        // Fallback to verified mock tasks if database has not yet seeded tasks
        setTasks(
          upcomingTasks.map((t) => ({
            id: t.id,
            _id: t.id,
            title: t.title,
            type: t.type || 'assignment',
            subjectCode: t.courseCode || 'CS601',
            description: t.description || 'Complete coursework submission and upload code artifacts.',
            dueDate: t.dueDate ? new Date(t.dueDate).toISOString() : new Date().toISOString(),
            estimatedHours: t.estimatedHours || 3,
            priority: t.priority?.toLowerCase() || 'medium',
            status: t.status === 'Completed' ? 'completed' : 'todo'
          }))
        );
      }
    } catch (err) {
      console.warn('[AssignmentsProjects] Fetch error:', err.message);
      setApiError(err.message || 'Unable to sync live deliverables from server. Showing cached session tasks.');
      // Keep verified initial tasks
      setTasks(
        upcomingTasks.map((t) => ({
          id: t.id,
          _id: t.id,
          title: t.title,
          type: t.type || 'assignment',
          subjectCode: t.courseCode || 'CS601',
          description: t.description || 'Complete coursework submission and upload code artifacts.',
          dueDate: t.dueDate ? new Date(t.dueDate).toISOString() : new Date().toISOString(),
          estimatedHours: t.estimatedHours || 3,
          priority: t.priority?.toLowerCase() || 'medium',
          status: t.status === 'Completed' ? 'completed' : 'todo'
        }))
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  // Filter tasks based on Type & Status
  const filteredTasks = tasks.filter((t) => {
    const matchesType = typeFilter === 'ALL' || t.type?.toLowerCase() === typeFilter.toLowerCase();

    const isDone = t.status === 'completed';
    const isOverdue = !isDone && t.dueDate && new Date(t.dueDate) < new Date('2026-11-15');

    let matchesStatus = true;
    if (statusFilter === 'PENDING') matchesStatus = !isDone && !isOverdue;
    if (statusFilter === 'COMPLETED') matchesStatus = isDone;
    if (statusFilter === 'OVERDUE') matchesStatus = isOverdue;

    return matchesType && matchesStatus;
  });

  // Toggle completion
  const handleToggleTask = async (taskId) => {
    const target = tasks.find((t) => t.id === taskId || t._id === taskId);
    if (!target) return;

    const newStatus = target.status === 'completed' ? 'todo' : 'completed';

    setTasks((prev) =>
      prev.map((t) =>
        t.id === taskId || t._id === taskId ? { ...t, status: newStatus } : t
      )
    );

    try {
      await taskService.updateTask(taskId, { status: newStatus });
    } catch (err) {
      console.warn('Could not sync task status to backend:', err);
    }
  };

  // Add new task
  const handleCreateTask = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const payload = {
        title: formData.title.trim(),
        type: formData.type,
        subjectCode: formData.subjectCode,
        description: formData.description.trim(),
        dueDate: new Date(formData.dueDate).toISOString(),
        estimatedHours: Number(formData.estimatedHours),
        priority: formData.priority
      };

      const res = await taskService.createTask(payload);
      const created = res.data || res.task || {
        id: `task-${Date.now()}`,
        _id: `task-${Date.now()}`,
        ...payload,
        status: 'todo'
      };

      setTasks([created, ...tasks]);
      setIsModalOpen(false);
      setToastMessage(`New deliverable '${formData.title}' added successfully!`);
      setTimeout(() => setToastMessage(null), 4000);

      // Reset form
      setFormData({
        title: '',
        type: 'assignment',
        subjectCode: 'CS601',
        description: '',
        dueDate: '2026-11-25',
        estimatedHours: 4,
        priority: 'medium'
      });
    } catch (err) {
      console.warn('Error adding task:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const pendingCount = tasks.filter((t) => t.status !== 'completed').length;
  const completedCount = tasks.filter((t) => t.status === 'completed').length + pastSubmissions.length;

  const submissionColumns = [
    {
      header: 'Deliverable Title',
      accessor: 'title',
      render: (row) => (
        <div>
          <span className="font-bold text-slate-900 block">{row.title}</span>
          <span className="text-xs text-slate-500 font-mono">{row.course}</span>
        </div>
      ),
    },
    {
      header: 'Category',
      accessor: 'type',
      render: (row) => (
        <Badge variant={row.type === 'Project' ? 'purple' : row.type === 'Presentation' ? 'amber' : 'blue'} size="sm">
          {row.type}
        </Badge>
      ),
    },
    {
      header: 'Submitted Date',
      accessor: 'submittedOn',
      cellClassName: 'text-slate-600 text-xs',
    },
    {
      header: 'Grade Received',
      accessor: 'grade',
      render: (row) => (
        <span className="font-bold text-slate-900">{row.grade}</span>
      ),
    },
    {
      header: 'Faculty Feedback',
      accessor: 'feedback',
      render: (row) => (
        <span className="text-xs text-slate-600 italic line-clamp-1 max-w-xs">{row.feedback}</span>
      ),
    },
    {
      header: 'Status',
      accessor: 'status',
      render: () => <Badge variant="green" size="sm" dot>Graded</Badge>,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        category="Academic Deliverables"
        title="Assignments, Projects & Presentations"
        description="Monitor active coursework deadlines, manage project submissions, and track evaluated faculty marks."
        actions={
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setIsModalOpen(true)}
          >
            Add Deliverable
          </Button>
        }
      />

      {/* API Notice / Error Banner if backend fails */}
      {apiError && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="truncate">{apiError}</span>
          </div>
          <button
            onClick={loadTasks}
            className="inline-flex items-center gap-1 font-semibold text-amber-800 hover:text-amber-950 underline shrink-0"
          >
            <RefreshCw className="w-3 h-3" /> Retry Connection
          </button>
        </div>
      )}

      {/* Toast Feedback */}
      {toastMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center justify-between gap-2 animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Pending Deliverables
            </span>
            <p className="text-3xl font-extrabold text-blue-600 mt-1 font-mono">{pendingCount}</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Active assignments & lab tasks</p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Completed Coursework
            </span>
            <p className="text-3xl font-extrabold text-emerald-600 mt-1 font-mono">{completedCount}</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Graded and approved submissions</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Overdue Submissions
            </span>
            <p className="text-3xl font-extrabold text-emerald-600 mt-1 font-mono">0</p>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">100% on-time submission rate</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Award className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-slate-700 text-xs font-bold uppercase tracking-wider">
            <Filter className="w-4 h-4 text-brand-600" />
            <span>Filters:</span>
          </div>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 py-1.5 px-3 font-semibold text-slate-800 bg-slate-50 focus:border-brand-500 focus:outline-none"
          >
            <option value="ALL">All Types (Assignments, Projects, Presentations)</option>
            <option value="assignment">Assignments Only</option>
            <option value="project">Projects Only</option>
            <option value="presentation">Presentations Only</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 py-1.5 px-3 font-semibold text-slate-800 bg-slate-50 focus:border-brand-500 focus:outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="PENDING">Pending Deliverables</option>
            <option value="COMPLETED">Completed</option>
            <option value="OVERDUE">Overdue</option>
          </select>
        </div>

        <span className="text-xs text-slate-500 font-medium">
          Showing {filteredTasks.length} task(s)
        </span>
      </div>

      {/* Active Tasks Grid */}
      <div className="space-y-3">
        <h3 className="text-base font-bold text-slate-900">Active Coursework Deliverables</h3>

        {filteredTasks.length === 0 ? (
          <div className="py-10 text-center bg-white rounded-2xl border border-slate-200 p-8 text-xs text-slate-500">
            <FileSpreadsheet className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-bold text-slate-700">No deliverables found matching filter criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTasks.map((task) => {
              const taskId = task.id || task._id;
              const isDone = task.status === 'completed';
              const isUrgent = task.priority === 'urgent' || task.priority === 'high';

              return (
                <div
                  key={taskId}
                  className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                    isDone
                      ? 'bg-emerald-50/30 border-emerald-200 opacity-80'
                      : 'bg-white border-slate-200 shadow-xs hover:shadow-md'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-mono text-xs font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded">
                        {task.subjectCode || 'CS601'}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <Badge
                          variant={task.type === 'project' ? 'purple' : task.type === 'presentation' ? 'amber' : 'blue'}
                          size="sm"
                        >
                          {task.type?.toUpperCase()}
                        </Badge>
                        <Badge variant={isUrgent ? 'red' : 'blue'} size="sm">
                          {task.priority?.toUpperCase()}
                        </Badge>
                      </div>
                    </div>

                    <div>
                      <h4
                        className={`text-sm font-bold leading-snug ${
                          isDone ? 'line-through text-slate-400' : 'text-slate-900'
                        }`}
                      >
                        {task.title}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                        {task.description}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>Due: {task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'Nov 25'}</span>
                      </div>
                      <span className="font-semibold text-slate-700">~{task.estimatedHours || 3} hrs</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => handleToggleTask(taskId)}
                      className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-colors ${
                        isDone
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-brand-50 text-brand-700 hover:bg-brand-100'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      {isDone ? 'Mark as Pending' : 'Mark Completed'}
                    </button>

                    <span className="text-[11px] font-semibold text-slate-400">
                      {isDone ? 'Submitted' : 'Pending'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Evaluated Past Submissions Table */}
      <div className="space-y-3 pt-2">
        <h3 className="text-base font-bold text-slate-900">Evaluated Coursework History & Feedback</h3>
        <DataTable
          columns={submissionColumns}
          data={pastSubmissions}
          keyField="id"
        />
      </div>

      {/* Add Deliverable Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Academic Deliverable"
        subtitle="Add a coursework task, laboratory assignment, or capstone presentation."
      >
        <form onSubmit={handleCreateTask} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Deliverable Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Operating Systems Kernel Module Assignment"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2.5 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
                Deliverable Type <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2.5 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
              >
                <option value="assignment">Assignment</option>
                <option value="project">Project / Lab Work</option>
                <option value="presentation">Presentation</option>
                <option value="study">Study Task</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
                Course Code <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.subjectCode}
                onChange={(e) => setFormData({ ...formData, subjectCode: e.target.value })}
                className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2.5 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
              >
                <option value="CS601">CS601: Algorithms</option>
                <option value="CS602">CS602: Database Systems</option>
                <option value="CS603">CS603: Computer Networks</option>
                <option value="CS604">CS604: Compiler Design</option>
                <option value="CS605">CS605: Machine Learning</option>
                <option value="CS606L">CS606L: Web Tech Lab</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
                Due Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
                Estimated Hours & Priority
              </label>
              <div className="grid grid-cols-2 gap-2 mt-1.5">
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={formData.estimatedHours}
                  onChange={(e) => setFormData({ ...formData, estimatedHours: e.target.value })}
                  className="rounded-xl border border-slate-300 py-2 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none"
                  placeholder="Hours"
                />
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                  className="rounded-xl border border-slate-300 py-2 px-2 text-xs text-slate-900 focus:border-brand-500 focus:outline-none"
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Description & Submission Requirements
            </label>
            <textarea
              rows={3}
              placeholder="State key problem statements, submission portal guidelines, or lab partners..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="mt-1.5 block w-full rounded-xl border border-slate-300 py-2 px-3 text-xs text-slate-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              size="md"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="md"
              loading={isSubmitting}
              icon={Check}
            >
              Save Deliverable
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AssignmentsProjects;
