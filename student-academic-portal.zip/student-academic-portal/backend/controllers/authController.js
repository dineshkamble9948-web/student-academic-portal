import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { isFallback } from '../config/db.js';
import {
  findFallbackStudentByEmail,
  addFallbackStudent
} from '../config/fallbackStore.js';
import Student from '../models/Student.js';

// Helper to generate token
const generateToken = (id) => {
  return jwt.sign(
    { id },
    process.env.JWT_SECRET || 'super_secret_jwt_academic_portal_key_2026_xyz',
    { expiresIn: process.env.JWT_EXPIRE || '7d' }
  );
};

// Send token helper (supports both cookie & JSON body for maximum client flexibility)
const sendTokenResponse = (student, statusCode, res) => {
  const token = generateToken(student._id || student.id);

  const options = {
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production'
  };

  // Safe student object without password
  const studentData = {
    id: student._id || student.id,
    name: student.name,
    email: student.email,
    rollNumber: student.rollNumber,
    department: student.department,
    degree: student.degree,
    semester: student.semester,
    academicYear: student.academicYear,
    section: student.section,
    avatar: student.avatar,
    mentor: student.mentor,
    stats: student.stats
  };

  res
    .status(statusCode)
    .cookie('token', token, options)
    .json({
      success: true,
      token,
      student: studentData
    });
};

// @desc    Register a new student
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
  try {
    const { name, email, password, rollNumber, department, semester } = req.body;

    if (!name || !email || !password || !rollNumber) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields (name, email, password, rollNumber).'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    if (isFallback()) {
      const existing = findFallbackStudentByEmail(email);
      if (existing) {
        return res.status(400).json({
          success: false,
          message: 'A student account is already registered with this email address.'
        });
      }

      const newStudent = await addFallbackStudent({
        name,
        email,
        password,
        rollNumber,
        department,
        semester
      });

      return sendTokenResponse(newStudent, 201, res);
    }

    // MongoDB Mongoose flow
    const existingStudent = await Student.findOne({
      $or: [{ email: email.toLowerCase() }, { rollNumber }]
    });

    if (existingStudent) {
      return res.status(400).json({
        success: false,
        message: 'A student account is already registered with this email or roll number.'
      });
    }

    const student = await Student.create({
      name,
      email: email.toLowerCase(),
      password,
      rollNumber,
      department: department || 'Computer Science & Engineering',
      semester: Number(semester) || 6
    });

    sendTokenResponse(student, 201, res);
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Server error occurred during registration.'
    });
  }
};

// @desc    Login student
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both institutional email and password.'
      });
    }

    if (isFallback()) {
      const student = findFallbackStudentByEmail(email);
      if (!student) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. No student account found with this email.'
        });
      }

      // If student has a bcrypt passwordHash or demo password check
      const isMatch = student.passwordHash
        ? await bcrypt.compare(password, student.passwordHash)
        : password === 'student123';

      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. Password did not match our records.'
        });
      }

      return sendTokenResponse(student, 200, res);
    }

    // MongoDB flow
    const student = await Student.findOne({ email: email.toLowerCase() }).select('+password');
    if (!student) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. No student account found with this email.'
      });
    }

    const isMatch = await student.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. Incorrect password.'
      });
    }

    sendTokenResponse(student, 200, res);
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Server error occurred during login.'
    });
  }
};

// @desc    Get currently logged in student profile
// @route   GET /api/auth/me
// @access  Private (JWT protected)
export const getMe = async (req, res) => {
  try {
    const student = req.student;
    res.status(200).json({
      success: true,
      student: {
        id: student._id || student.id,
        name: student.name,
        email: student.email,
        rollNumber: student.rollNumber,
        department: student.department,
        degree: student.degree,
        semester: student.semester,
        academicYear: student.academicYear,
        section: student.section,
        avatar: student.avatar,
        mentor: student.mentor,
        stats: student.stats
      }
    });
  } catch (err) {
    console.error('getMe error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve student profile session.'
    });
  }
};

// @desc    Logout student / clear cookie
// @route   POST /api/auth/logout
// @access  Public
export const logout = (req, res) => {
  res.cookie('token', 'none', {
    expires: new Date(Date.now() + 5 * 1000),
    httpOnly: true
  });
  res.status(200).json({
    success: true,
    message: 'Student logged out successfully.'
  });
};
