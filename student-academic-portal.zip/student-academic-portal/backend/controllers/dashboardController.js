// Dashboard Controller
export const getDashboardData = async (req, res) => {
  try {
    const student = req.student;

    // Academic benchmark comparison dataset
    const subjectPerformanceComparison = [
      {
        subjectCode: 'CS601',
        subjectName: 'Algorithms (DAA)',
        studentScore: 88,
        classAverage: 71,
        topScore: 96,
      },
      {
        subjectCode: 'CS602',
        subjectName: 'Database Systems',
        studentScore: 84,
        classAverage: 69,
        topScore: 98,
      },
      {
        subjectCode: 'CS603',
        subjectName: 'Computer Networks',
        studentScore: 72,
        classAverage: 68,
        topScore: 94,
      },
      {
        subjectCode: 'CS604',
        subjectName: 'Compiler Design',
        studentScore: 65,
        classAverage: 64,
        topScore: 92,
      },
      {
        subjectCode: 'CS605',
        subjectName: 'Machine Learning',
        studentScore: 92,
        classAverage: 74,
        topScore: 97,
      },
      {
        subjectCode: 'CS606L',
        subjectName: 'Web Tech Lab',
        studentScore: 95,
        classAverage: 82,
        topScore: 99,
      }
    ];

    const semesterTrendComparison = [
      {
        semester: 'Semester 1',
        studentScore: 8.10,
        classAverage: 7.20,
        topScore: 9.60,
      },
      {
        semester: 'Semester 2',
        studentScore: 8.25,
        classAverage: 7.35,
        topScore: 9.70,
      },
      {
        semester: 'Semester 3',
        studentScore: 8.15,
        classAverage: 7.10,
        topScore: 9.50,
      },
      {
        semester: 'Semester 4',
        studentScore: 8.55,
        classAverage: 7.45,
        topScore: 9.80,
      },
      {
        semester: 'Semester 5',
        studentScore: 8.70,
        classAverage: 7.60,
        topScore: 9.75,
      },
      {
        semester: 'Semester 6 (Projected)',
        studentScore: 8.85,
        classAverage: 7.65,
        topScore: 9.85,
      }
    ];

    const currentSemesterCourses = [
      {
        code: 'CS601',
        name: 'Design & Analysis of Algorithms',
        credits: 4,
        faculty: 'Dr. Arvind Gupta',
        attendance: 92,
        internalMarks: 44,
        studentScore: 88,
        classAverage: 71,
        topScore: 96,
        status: 'Strong',
        riskLevel: 'Low'
      },
      {
        code: 'CS602',
        name: 'Database Management Systems',
        credits: 4,
        faculty: 'Prof. Priya Venkatesh',
        attendance: 86,
        internalMarks: 42,
        studentScore: 84,
        classAverage: 69,
        topScore: 98,
        status: 'Proficient',
        riskLevel: 'Low'
      },
      {
        code: 'CS603',
        name: 'Computer Networks & Security',
        credits: 4,
        faculty: 'Dr. Rajeshwar Nair',
        attendance: 84,
        internalMarks: 36,
        studentScore: 72,
        classAverage: 68,
        topScore: 94,
        status: 'Needs Focus',
        riskLevel: 'Medium'
      },
      {
        code: 'CS604',
        name: 'Compiler Design',
        credits: 3,
        faculty: 'Prof. Sunita Menon',
        attendance: 78,
        internalMarks: 32,
        studentScore: 65,
        classAverage: 64,
        topScore: 92,
        status: 'Attention Required',
        riskLevel: 'High'
      },
      {
        code: 'CS605',
        name: 'Machine Learning Foundations',
        credits: 4,
        faculty: 'Dr. Vikram Seth',
        attendance: 95,
        internalMarks: 47,
        studentScore: 92,
        classAverage: 74,
        topScore: 97,
        status: 'Exemplary',
        riskLevel: 'Low'
      },
      {
        code: 'CS606L',
        name: 'Advanced Web Technologies Lab',
        credits: 2,
        faculty: 'Prof. Meera Joshi',
        attendance: 96,
        internalMarks: 48,
        studentScore: 95,
        classAverage: 82,
        topScore: 99,
        status: 'Exemplary',
        riskLevel: 'Low'
      }
    ];

    const upcomingTasks = [
      {
        id: 1,
        title: 'Algorithms Dynamic Programming Assignment',
        course: 'CS601 - DAA',
        dueDate: 'Tomorrow, 11:59 PM',
        dueTimestamp: '2026-11-16T23:59:00',
        priority: 'High',
        status: 'In Progress',
        progress: 75
      },
      {
        id: 2,
        title: 'DBMS Mini-Project Schema & Normalization Report',
        course: 'CS602 - DBMS',
        dueDate: 'Nov 19, 2026',
        dueTimestamp: '2026-11-19T17:00:00',
        priority: 'Medium',
        status: 'Drafting',
        progress: 40
      },
      {
        id: 3,
        title: 'Networks Wireshark Packet Capture Analysis',
        course: 'CS603 - CNS',
        dueDate: 'Nov 22, 2026',
        dueTimestamp: '2026-11-22T23:59:00',
        priority: 'High',
        status: 'Not Started',
        progress: 0
      }
    ];

    res.status(200).json({
      success: true,
      data: {
        student: {
          id: student._id || student.id,
          name: student.name,
          email: student.email,
          rollNumber: student.rollNumber,
          department: student.department,
          degree: student.degree,
          semester: student.semester,
          academicYear: student.academicYear,
          section: student.section,
          avatar: student.avatar,
          mentor: student.mentor,
          stats: student.stats || {
            cgpa: 8.42,
            cgpaScale: 10.0,
            targetCgpa: 9.0,
            classRank: 14,
            totalStudents: 120,
            totalCreditsCompleted: 112,
            totalCreditsRequired: 160,
            attendanceRate: 88.5,
            pendingAssignments: 3,
            activeMentorshipSessions: 2,
            studyHoursThisWeek: 26.5
          }
        },
        subjectPerformanceComparison,
        semesterTrendComparison,
        currentSemesterCourses,
        upcomingTasks
      }
    });
  } catch (err) {
    console.error('getDashboardData error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve academic dashboard analytics data.'
    });
  }
};
