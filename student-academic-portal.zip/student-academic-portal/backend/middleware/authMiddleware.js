import jwt from 'jsonwebtoken';
import { isFallback } from '../config/db.js';
import { findFallbackStudentById } from '../config/fallbackStore.js';
import Student from '../models/Student.js';

export const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route. Missing authentication token.'
    });
  }

  try {
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || 'super_secret_jwt_academic_portal_key_2026_xyz'
    );

    if (isFallback()) {
      const student = findFallbackStudentById(decoded.id);
      if (!student) {
        return res.status(401).json({
          success: false,
          message: 'Student session invalid or student no longer exists.'
        });
      }
      req.student = student;
      return next();
    }

    const student = await Student.findById(decoded.id).select('-password');
    if (!student) {
      return res.status(401).json({
        success: false,
        message: 'Student account not found.'
      });
    }

    req.student = student;
    next();
  } catch (err) {
    console.error('JWT verification error:', err.message);
    return res.status(401).json({
      success: false,
      message: 'Token has expired or is invalid. Please log in again.'
    });
  }
};

export default protect;
