import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const studentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide student name'],
      trim: true
    },
    email: {
      type: String,
      required: [true, 'Please provide institutional email'],
      unique: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address']
    },
    password: {
      type: String,
      required: [true, 'Please provide a password'],
      minlength: 6,
      select: false
    },
    rollNumber: {
      type: String,
      required: [true, 'Please provide student roll number'],
      unique: true,
      trim: true
    },
    department: {
      type: String,
      default: 'Computer Science & Engineering'
    },
    degree: {
      type: String,
      default: 'B.Tech'
    },
    semester: {
      type: Number,
      default: 6
    },
    academicYear: {
      type: String,
      default: '2023 - 2024'
    },
    section: {
      type: String,
      default: 'CSE - 6A'
    },
    avatar: {
      type: String,
      default: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80'
    },
    mentor: {
      name: { type: String, default: 'Dr. K. S. Rao' },
      designation: { type: String, default: 'Professor & Academic Mentor' },
      cabin: { type: String, default: 'Academic Block 3, Room 412' }
    },
    stats: {
      cgpa: { type: Number, default: 8.42 },
      cgpaScale: { type: Number, default: 10.0 },
      targetCgpa: { type: Number, default: 9.0 },
      classRank: { type: Number, default: 14 },
      totalStudents: { type: Number, default: 120 },
      totalCreditsCompleted: { type: Number, default: 112 },
      totalCreditsRequired: { type: Number, default: 160 },
      attendanceRate: { type: Number, default: 88.5 },
      pendingAssignments: { type: Number, default: 3 },
      activeMentorshipSessions: { type: Number, default: 2 },
      studyHoursThisWeek: { type: Number, default: 26.5 }
    }
  },
  {
    timestamps: true
  }
);

// Hash password before saving
studentSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Match password helper
studentSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

export const Student = mongoose.model('Student', studentSchema);
export default Student;
