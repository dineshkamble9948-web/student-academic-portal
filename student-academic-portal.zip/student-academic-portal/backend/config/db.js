import mongoose from 'mongoose';

let isUsingFallbackStore = false;

export const isFallback = () => isUsingFallbackStore;

export const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/student_academic_portal';
  try {
    mongoose.set('strictQuery', false);
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2500, // Quick timeout to fallback if MongoDB isn't running locally
    });
    console.log(`[Database] MongoDB Connected successfully: ${conn.connection.host}`);
    isUsingFallbackStore = false;
  } catch (err) {
    console.warn(`[Database] MongoDB connection error (${err.message}). Activating in-memory store for seamless standalone execution.`);
    isUsingFallbackStore = true;
  }
};

export default connectDB;
