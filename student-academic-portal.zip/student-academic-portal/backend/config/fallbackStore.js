import bcrypt from 'bcryptjs';

const initialPasswordHash = bcrypt.hashSync('student123', 10);

// Seed initial student Aarav Sharma
export const inMemoryStudents = [
  {
    _id: 'stu-aarav-048',
    id: 'STU-2022-CSE-048',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@college.edu',
    passwordHash: initialPasswordHash,
    rollNumber: '2022CSE048',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech',
    semester: 6,
    academicYear: '2023 - 2024',
    section: 'CSE - 6A',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    mentor: {
      name: 'Dr. K. S. Rao',
      designation: 'Professor & Academic Mentor',
      cabin: 'Academic Block 3, Room 412'
    },
    stats: {
      cgpa: 8.42,
      cgpaScale: 10.0,
      targetCgpa: 9.0,
      classRank: 14,
      totalStudents: 120,
      totalCreditsCompleted: 112,
      totalCreditsRequired: 160,
      attendanceRate: 88.5,
      pendingAssignments: 3,
      activeMentorshipSessions: 2,
      studyHoursThisWeek: 26.5
    }
  }
];

export const findFallbackStudentByEmail = (email) => {
  return inMemoryStudents.find((s) => s.email.toLowerCase() === email.toLowerCase());
};

export const findFallbackStudentById = (id) => {
  return inMemoryStudents.find((s) => s._id === id || s.id === id);
};

export const addFallbackStudent = async (studentData) => {
  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash(studentData.password, salt);
  const newStudent = {
    _id: `stu-${Date.now()}`,
    id: `STU-${studentData.rollNumber}`,
    name: studentData.name,
    email: studentData.email.toLowerCase(),
    passwordHash,
    rollNumber: studentData.rollNumber,
    department: studentData.department || 'Computer Science & Engineering',
    degree: studentData.degree || 'B.Tech',
    semester: Number(studentData.semester) || 6,
    academicYear: '2023 - 2024',
    section: 'CSE - 6A',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    mentor: {
      name: 'Dr. K. S. Rao',
      designation: 'Professor & Academic Mentor',
      cabin: 'Academic Block 3, Room 412'
    },
    stats: {
      cgpa: 8.42,
      cgpaScale: 10.0,
      targetCgpa: 9.0,
      classRank: 14,
      totalStudents: 120,
      totalCreditsCompleted: 112,
      totalCreditsRequired: 160,
      attendanceRate: 88.5,
      pendingAssignments: 3,
      activeMentorshipSessions: 2,
      studyHoursThisWeek: 26.5
    }
  };
  inMemoryStudents.push(newStudent);
  return newStudent;
};
