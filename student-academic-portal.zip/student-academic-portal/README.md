# Student Academic Portal 🎓
### Academic Analytics, Senior Mentorship & Smart Study Planner (Full-Stack Integrated)

A modern, production-grade full-stack web application designed for university students to track academic trajectory, compare against section toppers and class averages, book senior mentorship sessions, and organize smart study blocks.

---

## 🏗️ Architecture & Integration Overview

The application is structured into two cleanly separated tiers:
1. **Frontend**: React 18, Vite, Tailwind CSS, Recharts, Lucide React, and React Router v6.
2. **Backend**: Node.js, Express, MongoDB (Mongoose) with automatic standalone fallback store, JWT authentication, and CORS with credential support.

---

## 🚀 Exact Commands to Run Both Applications

### Terminal 1: Run the Node.js Backend API (Port 5000)
```powershell
cd "C:\Users\dines\.gemini\antigravity\scratch\student-academic-portal\backend"
npm install
npm start
```
> The API server will start on `http://localhost:5000` with the base route `http://localhost:5000/api`.

### Terminal 2: Run the React Frontend (Port 5173)
```powershell
cd "C:\Users\dines\.gemini\antigravity\scratch\student-academic-portal"
npm install
npm run dev
```
> Open your browser and navigate to: **[http://localhost:5173](http://localhost:5173)**

---

## 🔐 Authentication & Session Strategy

- **Token Storage**: Managed via `src/utils/tokenStorage.js` with support for both HttpOnly cookies and `Bearer <token>` headers.
- **Request Interceptor**: Centralized `apiClient` automatically attaches `Authorization: Bearer <token>` to all protected outgoing requests.
- **Response Interceptor**: Automatically catches `401 Unauthorized` responses and emits an `auth:unauthorized` session event that clears stale credentials and redirects visitors to `/login`.
- **Protected Routes**: `<ProtectedRoute>` guards all dashboard and analytics routes. Unauthenticated visitors are redirected to `/login`, saving their intended target destination in navigation state.
- **Session Persistence**: On page refresh or app reload, `AuthContext` queries `GET /api/auth/me` to verify the JWT token and load the student's live profile.

---

## 📡 Backend API Endpoints Reference

### 1. Authentication (`/api/auth`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Public | Register a new student account and issue JWT token |
| `POST` | `/api/auth/login` | Public | Authenticate student with email & password |
| `GET` | `/api/auth/me` | Protected | Retrieve authenticated student profile from JWT session |
| `POST` | `/api/auth/logout` | Public | Clear server authentication cookie |

### 2. Academic Dashboard (`/api/dashboard`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/dashboard` | Protected | Retrieve full student analytics, benchmark comparison, courses, and tasks |

### 3. System Health (`/api/health`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Public | Health check and server status |

---

## 🧪 Demo Credentials

For quick testing on the login page:
- **Email**: `aarav.sharma@college.edu`
- **Password**: `student123`
- *New registrations can also be performed with any institutional email on the `/register` page.*

---

## 🎨 Benchmark Graph Color Standards
- 🔵 **Logged-in Student**: Blue (`#2563EB`)
- 🟢 **Class Average**: Green (`#10B981`)
- 🔴 **Top Scorer / Section Topper**: Red (`#EF4444`)
